# Criado em:     2008-11-12                                                          
# Modificado em: 2016-08-30                                                         

#' @title  Create primary key and sort order
#' @description  Criacao de chave primária e sequência de ordenação a partir de um data frame contendo chaves estrangeiras
#' @usage chaveordem(dfestratos,chini=1,rtch=T)
#' @param dfestratos Data frame contendo uma ou mais chaves estrangeiras
#' @param chini Número inteiro indicando a chave primária inicial. Default=1
#' @param rtch Retornar apenas as chaves primárias. Default=F
#' @return Caso rtch==F - Lista de objetos:\cr 
#' co: Data frame contendo as chaves primárias e a sequência de ordenação,\cr 
#' reord: Reordenação (TRUE ou FALSE),\cr 
#' repid: Chaves primárias com repetição (TRUE ou FALSE),\cr 
#' nid: Número de chaves primárias.\cr 
#' Caso rtch==T - Vetor de números inteiros
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.br},\cr 
#' Monica Fabiana Bento Moreira \email{engagri@@yahoo.com.br}.
#' @keywords chaveordem
#' @examples chaveordem(data.frame(x=sample(1:5,100,T),y=sample(1:5,100,T)))
#' @rdname chaveordem
#' @export

chaveordem<-function(dfestratos,chini=1,rtch=T){
    chave<-as.matrix(dfestratos);
    nlin <- nrow(chave);
    nchave <- matrix(NA,nlin,2);
    if (ncol(chave) > 1) {
        nchave[,1] <- paste(letters[1], chave[, 1], sep = "");
        for (j in 2:ncol(chave)) {
            nchave[,1] <- paste(nchave[,1], letters[j], chave[, j], sep = "");
        }
    }else {
        nchave[,1] <- chave[, 1];
    }

    nchave[,2]<-seq(nlin);

    UChaveS <- unique(nchave[,1]);
    nid<-length(UChaveS);
    UChaveS<-data.frame(cs2=UChaveS,cn=seq(chini,(chini+nid-1),1), stringsAsFactors=FALSE);
    nchave <- data.frame(cs1=nchave[,1],ordini=nchave[,2],stringsAsFactors=FALSE);
    nchave <- merge(nchave, UChaveS, by.x = "cs1", by.y = "cs2", sort = FALSE);
    nchave<-nchave[order(as.numeric(nchave$ordini)),];

    nc <- as.integer(nchave$cn);
    
    if(rtch==F){
      ordfim<-order(nc);
      reord<-ifelse(sum(ordfim!=nchave$ordini)==0,FALSE,TRUE);
      repid<-ifelse(nid==nlin,FALSE,TRUE);
      
      nchave <- list(co=data.frame(chave = nchave[,'cn'], ordem = ordfim,stringsAsFactors=FALSE), reord=reord, repid=repid, nid=nid);
      return(nchave)
    }else{
      return(nc)
    }
}
