#' @title Resultados por parcela de um inventario florestal - Povoamento de Eucalyptus
#' sp.
#' 
#' @description O povoamento inventariado é heterogêneo, com idades variando de 4,5 a 6,5
#' anos, diferentes espaçamentos e materiais genéticos.  Apesar de plano, o
#' solo é muito arenoso e na região ocorre grandes períodos de estiagem, fato
#' que, contribui para o aumento da heterogeneidade do povoamento. O plano
#' amostral adotado foi a amostragem casual simples.
#' 
#' 
#' @name invflor1
#' @docType data
#' @format
#' 
#' data.frame: 328 obs. de 24 variáveis:\cr ..$ fazenda : int [1:328] Fazenda\cr
#' ..$ talhao : int [1:328] Talhão\cr ..$ area : num [1:328] Área do talhão
#' [ha]\cr ..$ espacamento : int [1:328] Espaçamento\cr ..$ matgen : int
#' [1:328] Material genético\cr ..$ clid : int [1:328] Classe de idade
#' [anos]\cr ..$ idade : num [1:328] Idade [anos]\cr ..$ parcela : int [1:328]
#' Parcela\cr ..$ areaparc : num [1:328] Área da parcela [m²]\cr ..$ nfustes :
#' num [1:328] Número de fustes por ha \cr ..$ percfalhas : num [1:328]
#' Percentual de falhas\cr ..$ percmortas : num [1:328] Percentual de árvores
#' mortas\cr ..$ percquebradas: num [1:328] Percentual de árvores quebradas\cr
#' ..$ hdom : num [1:328] Altura dominante [m]\cr ..$ hdom7 : num [1:328]
#' Altura dominante estimada para 7 anos [m]\cr ..$ areabasal : num [1:328]
#' Área basal [m²/ha]\cr ..$ ima : num [1:328] Incremento médio anual
#' [m³/ha.ano]\cr ..$ ima7 : num [1:328] Incremento médio anual estimado para 7
#' anos [m³/ha.ano]\cr ..$ vcomcc : num [1:328] Volume comercial com casca
#' [m³/ha]\cr ..$ vcomsc : num [1:328] Volume comercial sem casca [m³/ha]\cr
#' ..$ vcomcc7 : num [1:328] Volume comercial com casca estima para 7 anos
#' [m³/ha]\cr ..$ vtsc : num [1:328] Volume total sem casca [m³/ha]\cr ..$ vtcc
#' : num [1:328] Volume total com casca [m³/ha]\cr ..$ vtcc7 : num [1:328]
#' Volume total com casca estimado para 7 anos [m³/ha]\cr
#' @keywords datasets
NULL