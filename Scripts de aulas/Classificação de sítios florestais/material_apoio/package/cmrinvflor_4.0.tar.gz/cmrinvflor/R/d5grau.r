# Criado em: 2008-11-13                                                              
# Modificado em: 2010-03-24                                                          

#' @title Estimativa do diametro a qualquer altura utilizando o polinomio de quinto grau
#' 
#' @description Estimativa do diametro a qualquer altura utilizando o polinomio de quinto grau
#' 
#' @details  Todos os vetores das variáveis de entrada devem ter o mesmo tamanho 
#' inclusive os vetores de coeficientes
#' 
#' @param hi Iésima altura do fuste
#' @param dap Diâmetro à 1,3 metros de altura do solo
#' @param ht Altura total da árvore
#' @param B0 Coeficiente B0
#' @param B1 Coeficiente B1
#' @param B2 Coeficiente B2
#' @param B3 Coeficiente B3
#' @param B4 Coeficiente B4
#' @param B5 Coeficiente B5
#' @return São retornados os iésimos diâmetros das iésimas alturas dos fustes
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.br},\cr 
#' Monica F. B. M. Thiersch \email{engagri@@yahoo.com.br}.
#' @keywords d5grau
#' @rdname d5grau
#' @export
d5grau<-function (hi,dap,ht,b0,b1,b2,b3,b4,b5){
  d = dap*(b0+b1*(hi/ht)+b2*((hi/ht)^2)+b3*((hi/ht)^3)+b4*((hi/ht)^4)+b5*((hi/ht)^5));
  return(d);
}
