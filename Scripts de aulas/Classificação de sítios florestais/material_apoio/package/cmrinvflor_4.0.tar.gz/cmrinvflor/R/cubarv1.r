#' @title Resultados por arvore - Cubagem em Eucalyptus grandis
#' 
#' @description Resultados por árvore de uma cubagem em Eucalyptus grandis utilizando o
#' método proposto por Smalian.
#' 
#' @name cubarv1
#' @docType data
#' @format data.frame: 50 obs. de 6 variáveis:\cr 
#' ..$ estrato : int [1:50] Número do estrato\cr 
#' ..$ arv : int [1:50] Número da árvore\cr 
#' ..$ dap : num [1:50] Diâmetro à 1,3 metros do solo [cm]\cr 
#' ..$ ht : num [1:50] Altura total [m]\cr 
#' ..$ vicc : num [1:50] Volume individual com casca [m³/arv]\cr
#' ..$ visc : num [1:50] Volume individual sem casca [m³/arv]
#' @keywords cubagem
NULL