# Criado em:     2012-05-09                                                          
# Modificado em: 2016-09-20                                                          


#' @title Procurar dados entre duas tabelas com uma coluna identificadora em comum
#' 
#' @description  Procurar dados entre duas tabelas com uma coluna identificadora em comum
#' 
#' @usage procv(df_x, df_y, ret.y = 2, by.x = 1, by.y = 1, ndigits = 2,
#'              nao_loc = NA, ret_rel.x = FALSE)
#'
#' @param df_x 'Data frame' contendo os identificadores para os quais serão procurados os resultados\cr
#' @param df_y 'Data frame' contendo os identificadores e resultados a serem retornados
#' @param ret.y Vetor indicando as variáveis que deverão ser retornadas
#' @param by.x Vetor indicando as variáveis relacionais do df_x
#' @param by.y Vetor indicando as variáveis relacionais do df_y
#' @param ndigits Número de casas decimais caso is.numeric(df_x[by.x]) ou is.numeric(df_y[by.y])
#' @param nao_loc Valor padrão de retorno caso algum identificador não seja encontrado
#' @param ret_rel.x lógico: Retornar as variáveis relacionais da df_x
#' @return 'data frame ou vetor' contendo os dados localizados
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.com.br},\cr
#' Monica Fabiana Bento Moreira \email{engagri@@yahoo.com.br}.
#' @keywords procv
#' @rdname procv
#' @export
procv<-function(df_x, df_y, ret.y=2, by.x=1, by.y=1, ndigits=2, nao_loc=NA, ret_rel.x=FALSE){
  if(is.numeric(by.x)){ 
    by.x<-names(df_x)[by.x];
  }
  orig_by.x<-by.x;
  if(is.numeric(by.y)){ 
    by.y<-names(df_y)[by.y];
  }
  for (j in length(by.x)){
    if(is(df_x[[by.x[j]]],'numeric')) df_x[[by.x[j]]]<-trimws(format(as.numeric(df_x[[by.x[j]]]),nsmall=ndigits))
  }
  for (j in length(by.y)){
    if(is(df_y[[by.y[j]]],'numeric')) df_y[[by.y[j]]]<-trimws(format(as.numeric(df_y[[by.y[j]]]),nsmall=ndigits))
  }

  if(length(by.x)>1){
    vby.x<-apply(df_x[,by.x], 1, function(row) {
      as.character(paste0(row, collapse = "-"))
    })
    by.x<-paste0(by.x,collapse = '-');
    df_x[by.x]<-vby.x;
  }
  if(length(by.y)>1){
    vby.y<-apply(df_y[,by.y], 1, function(row) {
      as.character(paste0(row, collapse = "-"))
    })
    by.y<-paste0(by.y,collapse = '-');
    df_y[by.y]<-vby.y;
  }
  
  loc<-df_y[match(as.matrix(df_x[,by.x]), df_y[,by.y], nomatch = NA),ret.y];
  loc[is.na(loc)]<-nao_loc;
  if(ret_rel.x==T){
    loc<-cbind(df_x[,orig_by.x],loc);
    names(loc)<-c(orig_by.x,ret.y);
  }
  if(!is.vector(loc)){
    row.names(loc)<-NULL;
  }
  return(loc);
}
