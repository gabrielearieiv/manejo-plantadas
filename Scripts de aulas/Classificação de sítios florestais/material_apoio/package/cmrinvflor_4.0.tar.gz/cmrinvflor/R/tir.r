# Criado em:     2011-06-17                                                         
# Modificado em: 2012-06-06                                                          


#' @title Taxa interna de retorno
#' 
#' @description  Taxa interna de retorno
#' 
#' @param rc 'data frame'\cr
#'  ..$ [[1]]:    Período de ocorrência da receita ou custo. Ex: ano, mês, etc.\cr
#'  ..$ [[2]]:    Custo\cr
#'  ..$ [[3]]:    Receita
#' @param tir_esp: Taxa interna de retorno esperada. Default(0.1)
#' @param dif_vpr_vpc: Critério de parada: Diferença máxima aceita entre o valor presente das receitas e dos custos. Default (0.0001) 
#' @return tir: Taxa interna de retorno
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.br},\cr 
#' Monica F. B. M. Thiersch \email{engagri@@yahoo.com.br}.
#' @seealso avecon
#' @keywords tir
#' @rdname tir
#' @export
tir<-function(rc, tir_esp, dif_vpr_vpc){
  if (missing(tir_esp)) tir_esp <- 0.1;
  if (missing(dif_vpr_vpc)) dif_vpr_vpc <- 0.0001;
  tj <- tir_esp;
  
  custos  <-rc[rc[,2]!=0 & is.na(rc[,2])==F, c(1,2)];
  receitas<-rc[rc[,3]!=0 & is.na(rc[,3])==F, c(1,3)];

  custos[,2]<-abs(custos[,2]);
  receitas[,2]<-abs(receitas[,2]);
  
  vpr<-vp(receitas,tj)
  vpc<-vp(custos,tj)

  inc <- 1
  while (abs(vpr - vpc) > dif_vpr_vpc){
      inc = inc / 10;
      if(vpr < vpc){
          while(vpr < vpc){
            tj = tj - inc
            vpr<-vp(receitas,tj)
            vpc<-vp(custos,tj)
          }
      } else{
          while(vpr > vpc){
              tj <- tj + inc
              vpr<-vp(receitas,tj)
              vpc<-vp(custos,tj)
          }
      }
  }
  return(tj);
}
