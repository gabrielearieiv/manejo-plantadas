# Criado em:     2010-09-16                                                              
# Modificado em: 2018-11-12                                                          

#' @title Calculo das estatisticas da amostragem casual simples
#' 
#' @description  Cálculo das estatísticas da amostragem casual simples
#' 
#' @usage estats_acs(vy, nt=Inf, sig=5, emperc=NULL)
#' 
#' @param vy: Vetor de observações da variável de interesse\cr
#' @param nt: Número total de amostras cabíveis. 
#' @param sig: Nível de significância em porcentagem (0 a 100). 
#' @param emperc: Erro máximo percentual aceito para a estimativa da suficiência amostral
#' 
#' @return 
#' 'lista'\cr 
#' ..$ ymed: Média\cr 
#' ..$ na: Número de unidades amostrais\cr 
#' ..$ s2dy: Variância\cr 
#' ..$ sdy: Desvio padrão\cr 
#' ..$ cv: Coeficiente de variação em porcentagem\cr 
#' ..$ sdymed: Erro padrão da média\cr 
#' ..$ eunid: Erro na unidade da variável de interesse\cr 
#' ..$ eperc: Erro em percentagem\cr 
#' ..$ li: Limite inferior do intervalo de confiança\cr 
#' ..$ ls: Limite superior do intervalo de confiança\cr 
#' ..$ sa: Suficiência amostral para o erro máximo pré-estabelecido <!is.null(emperc)>
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.br},\cr 
#' Monica Fabiana Bento Moreira \email{engagri@@yahoo.com.br}.
#' @keywords estats_acs
#' @rdname estats_acs
#' @export
estats_acs<-function(vy,nt=Inf,sig=5,emperc=NULL){
  vy<-as.vector(vy);
  na<-length(vy);
  ymed<-mean(vy);
  s2dy<-var(vy);
  sdy<-sd(vy);
  cv<-(sdy/ymed)*100;
  sdymed<-sqrt((s2dy/na)*(1-(na/nt)));
  eunid<-qt(1 - (sig/200), na - 1)*sdymed;
  eperc<-(eunid/ymed)*100;
  li<-ymed - eunid;
  ls<-ymed + eunid;
  eacs<-list(ymed=ymed,na=na,s2dy=s2dy,sdy=sdy,cv=cv,sdymed=sdymed,eunid=eunid,eperc=eperc, li=li,ls=ls)
  if(!is.null(emperc)) eacs<-c(eacs,sa=nacs(vy, eperc=emperc, sig=sig, N=nt));
  return(eacs);
}
