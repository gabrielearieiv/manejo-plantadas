# Criado em:     2012-09-22
# Modificado em: 2024-06-25

#' @title Site classification by algebraic difference
#' @description  Site classification by algebraic difference
#' @param equation 'list'\cr
#'  ..$ required_variables Variáveis obrigatórias\cr
#'  ..$ fpred Função para predição da variável de interesse\cr
#'  ..$ parms 'list' Parâmetros estimados\cr
#'  ..$ present_age_variable: Variável idade de medição presente\cr
#'  ..$ future_age_variable: Variável idade de medição futura\cr
#'  ..$ present_dominant_height_variable: Variável altura dominante presente\cr
#'  ..$ future_dominant_height_variable: Variável altura dominante futura
#' @param continuous_sample_plots: 'data frame'\cr
#'  ..$ id: chave primária de identificação da amostra\cr
#'  ..$ Variável idade de medição presente definida no parâmetro equation\cr
#'  ..$ Variável altura dominante presente definida no parâmetro equation
#' @param reference_age: Idade de referência (default: 72 meses)
#' @param site_class_limits: Vetor contendo os limites das classes de sítio. 
#' Caso is.na(site_class_limits), o sistema irá solicitar automaticamente outras
#' informações para a continuidade do processamento.
#' @param way_counting_migrations: forma de contagem das migrações\cr
#'  ..$ 1: Migrações independentes da idade de medição\cr
#'  ..$ 2: Migrações em cada idade de medição 
#' @param plot_curves: Plotar um gráfico com as curvas estimadas e as alturas dominantes observadas (default: TRUE).
#' @return $ 'list'\cr 
#' ....$ continuous_sample_plots: 'data frame'\cr 
#' ....$ id: chave primária de identificação da amostra\cr
#' ....$ Present age variable definida no parâmetro equation\cr
#' ....$ Present dominant height variable definida no parâmetro equation\cr
#' ....$ Alturas dominantes estimadas por todas as curvas em todas as idades de medição \cr 
#' ....$ is: Índice de sítio de cada amostra/medição \cr 
#' ....$ nmudou: Número de vezes que cada amostra mudou de classe de sítio \cr 
#' ....$ nis: Idêntico ao vetor 'is' para posterior reclassificação manual. \cr
#' ..$ classes: 'data frame' contendo as alturas dominantes estimadas por todas as curvas na idade de referência.\cr 
#' ..$ estabilidade: 'data frame'
#' ....$migracao: Número de mudanças de classes de sítio \cr 
#' ....$n_ocorrencia: Número de ocorrências de cada migração \cr 
#' ....$percmudanca: Percentual de ocorrências de cada migração
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.br},\cr 
#' Monica Fabiana Bento Moreira \email{engagri@@yahoo.com.br}.
#' @rdname siteClassificationAlgebraicDifference
#' @export

#siteClassificationAlgebraicDifference
siteClassificationAlgebraicDifference<-function(
    equation, 
    continuous_sample_plots, 
    reference_age=72, 
    site_class_limits=NA, 
    way_counting_migrations=1, 
    plot_curves=T
){
  rv<-c("id",equation$required_variables)
  jj<-rv %in% c(names(continuous_sample_plots), equation$future_age_variable, equation$future_dominant_height_variable)
  if(sum(jj)<length(rv)){
    stop(
      script('Não foram localizadas as variáveis obrigatórias:', rv[!jj], collapse=' '), 
      call. = F
    )
  }
  if (is.na(site_class_limits)){
    continuous_sample_plots[[equation$future_age_variable]]<-reference_age;
    continuous_sample_plots$sitio<-equation$fpred(continuous_sample_plots, equation$parms);
    
    lim_hdiref<-round(c(min(continuous_sample_plots$sitio),max(continuous_sample_plots$sitio)),2);
    
    desc_inf<-paste('Os limites, inferior e superior, das curvas na idade de referência são respectivamente: \n ',lim_hdiref[1],' e ',lim_hdiref[2],'.\n',
                    ' Deseja alterar estes valores? Afirmativo(T) ou Negativo(F) \n', sep='')
    
    if(as.logical(inf_user(desc_inf,1,'logical'))){
      desc_inf<-'Informe os novos limites, inferior e superior respectivamente, das curvas na idade de referência.'
      lim_hdiref<-as.numeric(inf_user(desc_inf,2,'numeric'));
    }
    
    desc_inf<-'Informe o número de classes desejado:';
    nclasses<-as.integer(inf_user(desc_inf,1,'integer'));
    
    site_class_limits<-seq(lim_hdiref[2],lim_hdiref[1],length.out=nclasses+1);
  }else{
    site_class_limits<-site_class_limits[order(site_class_limits, decreasing = T)];
  } 
  ncurvas<-length(site_class_limits);
  classes<-data.frame(nomcol=paste('lscl',1:ncurvas,sep=''),s=site_class_limits,stringsAsFactors =F);
  classes[ncurvas,1]<-paste('licl',ncurvas-1,sep='');
  x<-continuous_sample_plots
  x[[equation$future_age_variable]]<-continuous_sample_plots[[equation$present_age_variable]]
  x[[equation$present_age_variable]]<-reference_age
  for(i in ncurvas:1){
    x[[equation$present_dominant_height_variable]]<-classes[i,2]
    continuous_sample_plots[[classes[i,1]]]<-equation$fpred(x, equation$parms)
  }
  
  if(plot_curves==T){
    dados_graf<-continuous_sample_plots[order(continuous_sample_plots[[equation$present_age_variable]]),];
    with(dados_graf, plot(
      x=dados_graf[[equation$present_age_variable]], 
      y=dados_graf[[equation$present_dominant_height_variable]], 
      ylim=c(0,40), 
      pch='*', 
      col='green', 
      xlab=equation$present_age_variable, 
      ylab=equation$present_dominant_height_variable
    ));
    for(i in ncurvas:1){
      lines(dados_graf[[equation$present_age_variable]], dados_graf[,classes[i,1]], col=i);
    }
    legend(
      "bottomright",
      legend=round(classes[,2],2),
      col=1:ncurvas,
      lty=rep(1,ncurvas), 
      lwd=rep(2.5,ncurvas), 
      cex=0.8, 
      box.col="white", 
      bty="n"
    );
  }
  continuous_sample_plots$is<-NA;
  for(i in (ncurvas-1):2){
    continuous_sample_plots$is[
      continuous_sample_plots$hdom<continuous_sample_plots[,classes[i,1]] & 
      is.na(continuous_sample_plots$is)
    ]<-i;
  }
  continuous_sample_plots$is[is.na(continuous_sample_plots$is)]<-1
  
  #forma de contagem das migrações
  #1: Migrações independente da idade de medição
  #2: Migrações em cada idade de medição
  if(is.na(way_counting_migrations)|way_counting_migrations!=2) way_counting_migrations<-1
  if(way_counting_migrations==1){
    f<-function(x){
      if(nrow(x)>1){
        x<-x[order(x$is),]
        resp<-data.frame(id=x$id[1], nmudou=sum(diff(x$is)))
      } else{
        resp<-data.frame(id=x$id[1], nmudou=0)
      }
      return(resp)
    }
    calc<-Reduce('rbind', lapply(split(continuous_sample_plots, continuous_sample_plots$id),f))
  }else{
    f<-function(x, var_order){
      if(nrow(x)>1){
        x<-x[order(x[[var_order]]),]
        resp<-data.frame(id=x$id[1], nmudou=sum(abs(diff(x$is))))
      } else{
        resp<-data.frame(id=x$id[1], nmudou=0)
      }
      return(resp)
    }
    calc<-Reduce(
      'rbind', 
      lapply(
        split(continuous_sample_plots,continuous_sample_plots$id),
        f, 
        equation$present_age_variable
      )
    )
  }
  
  continuous_sample_plots<-merge(x = continuous_sample_plots, y = calc, by = "id",  all.x=T,sort=F);
  continuous_sample_plots$nis<-continuous_sample_plots$is;

  estabilidade<-aggregate(list(n_ocorrencia=calc$id),list(migracao=calc$nmudou),length);
  estabilidade$percmudanca<-with(estabilidade,round(n_ocorrencia/sum(n_ocorrencia)*100,2));
  
  names(classes)<-c('limite',paste('hdiref_',reference_age,sep=''));
  
  continuous_sample_plots$sitio<-NULL
  continuous_sample_plots<-continuous_sample_plots[
    order(
      continuous_sample_plots$id, 
      continuous_sample_plots[[equation$present_age_variable]]
    ),
  ];
  return(list(
    continuous_sample_plots=continuous_sample_plots,
    classes=classes,
    estabilidade=estabilidade
  ))
}
