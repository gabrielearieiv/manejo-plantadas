# Criado em:     2021-03-01                                                          
# Modificado em: 2022-11-23         

#' @title Open a file using Linux or Windows file associations
#' @description Opens the specified file using the application specified in the Linux or Windows file associations.
#' @param file file to be opened.
#' @param command Similar to the command object used in the \code{\link[base]{system2}} function  (Linux Only).
#' @param args Similar to the command object used in the \code{\link[base]{system2}} function  (Linux Only).
#' @param sh_quote_file Quote string "file" for use in OS Shells.
#' @param wait Similar to the wait object used in the \code{\link[base]{system2}} function (Linux Only).
#' @param ... Other objects used by the function \code{\link[base]{system2}} (Linux Only).
#' @return No value, but informative error messages will be given if the operation fails.
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.br},\cr 
#' Monica F. B. M. Thiersch \email{engagri@@yahoo.com.br}.
#' @rdname shellExec
#' @export

shellExec<-function(file, command='xdg-open', args=character(), sh_quote_file=F, wait=F,...){
  if(sh_quote_file) file<-shQuote(file)
  if(.Platform$OS.type!='unix'){
    file<-chartr('/','\\',file)
    shell.exec(file);
  }else{
    if(length(args)>0){
      args<-paste(paste0(args, collapse=" "), file, collapse=" ")
    }else(
      args<-file
    )
    system2(command=command, args=args, wait=wait, ...)
  }
}
