# Criado em:     2012-09-22
# Modificado em: 2012-09-22


#' @title Solicitacao de informacoes ao usuario
#' 
#' @description  Solicitacao de informacoes ao usuario
#' 
#' @param desc_inf Descrição das informações solicitadas
#' @param nresp Número de informações solicitadas
#' @param tipo_var_res Tipo da varíavel resposta.  Opções: 'logical', 'integer', 'numeric', 'complex', 'character' e 'raw'.
#' 
#' @return Vetor contendo as informações solicitadas na mesma ordem que foram inseridas pelo usuário
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.br},\cr 
#' Monica Fabiana Bento Moreira \email{engagri@@yahoo.com.br}.
#' @rdname inf_user
#' @export
inf_user<-function(desc_inf,nresp,tipo_var_res){
  if (missing(desc_inf)) desc_inf='Informe:';
  if (missing(nresp)) nresp=1;
  if (missing(tipo_var_res)) tipo_var_resp='numeric';
  cat(desc_inf,"\n");
  return(scan(what=tipo_var_res,nmax=nresp))
}
