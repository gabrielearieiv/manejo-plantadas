# Criado em:     2012-06-06                                                         
# Modificado em: 2012-08-24                                                          


#' @title Avaliacao economica de projetos florestais
#' 
#' @description Avaliacao economica de projetos florestais
#' 
#' @param prc: 'data frame'\cr
#'  ..$ [[1]]:    Identificador do projeto \cr
#'  ..$ [[2]]:    Período de ocorrência da receita ou custo. Ex: ano, mês, etc.\cr
#'  ..$ [[3]]:    Custo\cr
#'  ..$ [[4]]:    Receita\cr
#'  ..$ [[5]]:    Quantidade produzida. Obrigatório apenas se calc_cmpr = TRUE 
#' @param tj: Taxa de juros(anual, mensal, etc.). Default(0.1)
#' @param vt: Valor de terra. Default (0) 
#' @param calc_cmpr: Calcular o custo médio de produção? (F ou T). Default (FALSE) 
#' @param dif_vpr_vpc: Critério de parada da tir: Diferença máxima aceita entre o valor presente das receitas e dos custos. Default (0.0001) 
#' @return 'data frame' \cr ..$[[1]]: Identificador do projeto \cr ..$vpc:
#' Valor presente dos custos \cr ..$vpr: Valor presente das receitas \cr
#' ..$vpl: Valor presente líquido \cr ..$tir: Taxa interna de retorno \cr
#' ..$bc: Benefício/Custo \cr ..$cmpr: Custo médio de produção. Caso calc_cmpr
#' = TRUE \cr ..$vplinf: Valor presente líquido infinito \cr ..$vet: Valor
#' esperado da terra \cr ..$bpe: Benefício periódico equivalente 
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.br},\cr Monica F.
#' B. M. Thiersch \email{engagri@@yahoo.com.br}.
#' @seealso vp, vpinf e tir
#' @keywords avecon
#' @rdname avecon
#' @export
avecon<-function(prc, tj, vt, calc_cmpr, dif_vpr_vpc){
  if (missing(tj)) tj <- 0.1;
  if (missing(vt)) vt<-0;
  if (missing(calc_cmpr)) calc_cmpr<-FALSE;
  if (missing(dif_vpr_vpc)) dif_vpr_vpc <- 0.0001;
  
  prc[is.na(prc)]<-0;
  
  dfecon<-data.frame(projeto=unique(prc[,1]), vpc=NA, vpr=NA, vpl=NA, tir=NA, bc=NA, cmpr=NA, vplinf=NA, vet=NA, bpe=NA);
  names(dfecon)<-c(names(prc)[1], 'vpc', 'vpr', 'vpl', 'tir', 'bc', 'cmpr', 'vplinf', 'vet', 'bpe');  

  vp_proj<-function(x, prc, tj, col_rc){
    return(vp(subset(prc, prc[,1]==x,c(2, col_rc)),tj));
  }

  tir_proj<-function(x, prc, tj){
    return(tir(prc[prc[,1]==x,c(2:4)], tj));
  }

  vpinf_proj<-function(x, prc, tj, col_rc){
    return(vpinf(subset(prc, prc[,1]==x,c(2, col_rc)),tj));
  }

  x<-as.matrix(dfecon[,1]);
  dfecon$vpc<-apply(x, 1, vp_proj, prc, tj, 3);
  dfecon$vpr<-apply(x, 1, vp_proj, prc, tj, 4);
  dfecon$vpl<-dfecon$vpr-dfecon$vpc;
  dfecon$tir<-apply(x, 1, tir_proj, prc, tj);
  dfecon$bc<-dfecon$vpr/dfecon$vpc;
  dfecon$vplinf<-apply(x, 1, vpinf_proj, prc, tj, 4)-apply(x, 1, vpinf_proj, prc, tj, 3);
  dfecon$vet<-dfecon$vplinf+vt;
  dfecon$bpe<-dfecon$vplinf*tj;
  if(ncol(prc)>=5 & calc_cmpr==TRUE){
    dfecon$cmpr<-dfecon$vpc/apply(x, 1, vp_proj, prc, tj, 5)
  } else{
    dfecon$cmpr<-NULL;
  } 
  return(dfecon);
}
