# Criado em:     2012-09-23
# Modificado em: 2020-07-04

#' @title Cubagem rigorosa utilizando o metodo de Smalian
#' 
#' @description  Cubagem rigorosa utilizando o metodo de Smalian
#' 
#' @param  cub 'data frame' \cr
#' --(02 opções sendo que as variáveis devem estar na mesma ordem das variáveis descritas abaixo) \cr
#' .. \cr
#' --Opção 01: dap e ht informados em colunas separadas \cr
#' ..$ idfustemed: Chave primária do fuste medição\cr
#' ..$ dap: Diâmetro ou circunferência (cm) a 1,3 metros do chão \cr
#' ..$ ht:  Altura total(m) \cr
#' ..$ hi: Iésima altura de medição do diâmetro ao longo do fuste (m) \cr
#' ..$ dicc: Diâmetro com casca na iésima altura de medição ao longo do fuste (m) \cr 
#' ..$ espcasca: Espessura da casca (cm) - espcasca=(dicc-disc)/2. Obrigatório apenas se a opção comcasca for igual a FALSE \cr  
#' .. \cr
#' --Opção 02: Nas alturas de medição deverá haver a altura em que hi=ht, dicc=0 e espcasca=0 \cr
#' ..$ idfustemed: Chave primária do fuste medição\cr
#' ..$ hi: Iésima altura de medição do diâmetro ao longo do fuste (m) \cr
#' ..$ dicc: Diâmetro com casca na iésima altura de medição ao longo do fuste (m) \cr 
#' ..$ espcasca: Espessura da casca (cm) - espcasca=(dicc-disc)/2. Obrigatório apenas se a opção comcasca for igual a FALSE \cr  
#' OBS: Caso a opção comcasca for igual a TRUE, a variável 'espcasca' deverá ser removida do 'data frame' amostras \cr
#' .. 
#' @param dcoms Vetor de diâmetros comerciais (cm) - Default: c(3.0)
#' @param htoco Altura do toco (cm) - Default: 10
#' @param comcasca Estimar volumes com casca (TRUE) ou sem casca (FALSE) - Default: TRUE 
#' @param di_ou_ci diâmetros (di) ou circunferências (ci) mensuradas - Default: 'di'
#' @param hcil_toco Altura do toco (cm) até o qual sera aplicada a fórmula do cilindro - Default: hcil_toco=htoco
#' @param dbase_ponta Diâmetro (cm) a partir do qual será aplicada a fórmula do cone - Default: dbase_ponta=minimo(dcoms)

#' @return 'data frame'\cr 
#' ..$ Variáveis do nível fuste do objeto cub\cr 
#' ..$ vprod_dcoms: Os volumes (m³) para cada diâmetro mínimo comercial \cr 
#' ..$ vtoco: Volume do toco (m³) \cr 
#' ..$ vponta: Volume da ponta definido pelo menor diâmetro mínimo comercial \cr 
#' ..$ vcilcc: Volume do cilindro com casca (m³) para calculo do fator de forma normal. \cr
#' ..$ vtcc ou vtsc: Volume total com ou sem casca (m³). \cr
#' ..$ ffcc ou ffsc: fator de forma com ou sem casca (m³).
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.br},\cr 
#' Monica Fabiana Bento Moreira \email{engagri@@yahoo.com.br}.
#' @keywords smalian cubagem
#' @rdname smalian
#' @export
smalian<-function(cub,dcoms=3,htoco=10,comcasca=T,di_ou_ci='di',hcil_toco=htoco,dbase_ponta=min(dcoms)){
  #if (missing(dbase_ponta)) dbase_ponta<-min(dcoms);
  
  dcoms<-dcoms[order(dcoms,decreasing=T)];

  if(hcil_toco >= 100) stop('A altura da seção cilíndrica do toco deve ser menor que 100cm', call. = FALSE);
  if(htoco < hcil_toco) stop('A altura do toco deve ser maior ou igual a altura definida para seção cilíndrica do toco', call. = FALSE);
  if(htoco >= 100) stop('A altura do toco deve ser menor que 100cm', call. = FALSE);
  if(min(dcoms) < dbase_ponta) stop('Os diâmetros comerciais devem ser maiores ou iguais ao diâmetro da base da ponteira', call. = FALSE);

  hcil_toco<-hcil_toco/100;
  htoco<-htoco/100;
  
  if(comcasca==T){
    if(ncol(cub) != 5 & ncol(cub) != 3) stop('Número incorreto de variáveis no arquivo de cubagem', call. = FALSE);
    if(ncol(cub) == 5){
      bknames<-names(cub)[1:3];
      names(cub)<-c('idfustemed','dap','ht','hi','dicc');
      padrao=1;
    }else{
      bknames<-names(cub)[1];
      names(cub)<-c('idfustemed','hi','dicc');
      padrao=2
    }
  }else{
    if(ncol(cub) != 6 & ncol(cub) != 4) stop('Número incorreto de variáveis no arquivo de cubagem', call. = FALSE);
    if(ncol(cub) == 6){
      bknames<-names(cub)[1:3];
      names(cub)<-c('idfustemed','dap','ht','hi','dicc','espcasca');
      padrao=1;
    }else{
      bknames<-names(cub)[1];
      names(cub)<-c('idfustemed','hi','dicc','espcasca');
      padrao=2
    }
  }  

  if(di_ou_ci=='ci'){
    if(padrao==1) cub$dap<-cub$dap/pi;
    cub$dicc<-cub$dicc/pi;
  }
  
  if(padrao==2){
    fmdmin<-with(cub, aggregate(list(dmin=dicc),list(idfustemed=idfustemed),min));
    if(sum(fmdmin$dmin!=0)>0){
      stop('Erro: Em todas as árvore o menor diâmetro deve ser igual a 0 na posição onde hi=ht!', call. = FALSE);
    }
    rm(fmdmin);
  }
  
  if(comcasca==F){
    cub$di<-cub$dicc-(2*cub$espcasca)        
    if(sum(cub$di<0)){
      stop('Erro: A espessura da casca (x 2) não pode ser maior ou igual ao diâmetro mensurado', call. = FALSE);
    }
    cub$espcasca<-NULL;
  }else{
    cub$di<-cub$dicc;
  }
  
  pcub<-parear_seqmed(cub[,c('idfustemed','hi','di')]);
  perigo<-sum(pcub$di2>pcub$di1);
  if(perigo>0){
    warning(paste0('Ocorrência de ',perigo,' aumento(s) de di no sentido longitudinal dos fustes.'),call.=F);
  }

  ##Garantindo que o dicc reduz com o aumento do hi em cada árvore
  #Esta validação deve ter a implementação melhorada
  # for(i in 2:nrow(cub)){
  #   if(cub$idfustemed[i]==cub$idfustemed[i-1] & cub$di[i]>cub$di[i-1]){
  #     cub$di[i]<-cub$di[i-1];
  #     cub$dicc[i]<-cub$dicc[i-1];
  #   }
  # }
  
  nfm<-length(unique(cub$idfustemed));
    
  if(padrao==1){
    #Inserido o dap entre as seções de medição
    fms_cdap<-cub$idfustemed[cub$hi==1.30]
    if(length(fms_cdap)<nfm){
      cub_sdap<-subset(cub, !idfustemed %in% fms_cdap & duplicated(idfustemed)==F);
      cub_sdap$hi<-1.30;
      cub_sdap$dicc<-cub_sdap$dap;
      if(comcasca==T){
        cub_sdap$di<-cub_sdap$dap;
      }else{
        cub_sdap$di<-NA;
      }
      cub<-rbind(cub,cub_sdap)
#       if(comcasca==F){
#         cub<-cub[order(cub$idfustemed,cub$hi),];
#         ii<-seq(1,nrow(cub))[cub$hi==1.3 & is.na(cub$di)];
#         cub$di[ii]<-with(cub,dicc[ii]-(dicc[ii+1]-di[ii+1])-((((dicc[ii+1]-di[ii+1])-(dicc[ii-1]-di[ii-1]))*(hi[ii+1]-1.3))/(hi[ii+1]-hi[ii-1])));
#       }
      rm(cub_sdap);
    }
    rm(fms_cdap);
  
    #Inserindo a ht entre as seções de medição
    fms_cht<-cub$idfustemed[cub$dicc==0]
    if(length(fms_cht)<nfm){
      cub_sht<-subset(cub, !idfustemed %in% fms_cht & duplicated(idfustemed)==F);
      cub_sht$hi<-cub_sht$ht;
      cub_sht$dicc<-0;
      cub_sht$di<-0;
      cub<-rbind(cub,cub_sht)
      rm(cub_sht);
    }
    rm(fms_cht);
  
  }else{
    fm_ht<-subset(cub, dicc==0, c('idfustemed','hi'));
    fm_ht$ht<-fm_ht$hi;
    fm_ht$hi<-NULL;
    cub<-merge(cub, fm_ht);
    rm(fm_ht);
  }
  val_hi<-with(cub,aggregate(list(mhi=hi, ht=ht),list(idfustemed=idfustemed),max));
  if(sum(val_hi$mhi>val_hi$ht)>0) stop('Existem árvores com altura de seção maior que a altura total (hi>ht).', call. = FALSE);
  rm(val_hi);
  
  cub<-cub[order(cub$idfustemed,cub$hi),];

  #Garantindo que o di reduz com o aumento do hi em cada árvore
  #for(i in 2:nrow(cub)){
  #  if(cub$idfustemed[i]==cub$idfustemed[i-1] & cub$dicc[i]>cub$dicc[i-1]) cub$dicc[i]<-cub$dicc[i-1];
  #  if(cub$idfustemed[i]==cub$idfustemed[i-1] & cub$di[i]>cub$di[i-1]) cub$di[i]<-cub$di[i-1];
  #}
  
  #Inserindo novos his e interpolando os dis
  if(hcil_toco!=htoco){
    nhis<-c(hcil_toco,htoco)
  }else{
    nhis<-c(htoco)
  }
  
  if(padrao==2) nhis<-c(nhis,1.3);
  
  for(j in 1:length(nhis)){
    fms_cdi<-cub[cub$hi==nhis[j], ];
    if(nrow(fms_cdi)<nfm){
      if(nrow(fms_cdi)==0){
        cub_sdi<-cub;
      }else{
        cub_sdi<-subset(cub, !idfustemed %in% fms_cdi$idfustemed);  
      }
      #cub_sdi<-cub_sdi[order(cub_sdi$idfustemed,cub_sdi$hi),];
      nfm_sdi<-length(unique(cub_sdi$idfustemed))
      fms_sdi<-subset(cub_sdi,duplicated(idfustemed)==F);
      fms_sdi$hi<-nhis[j];
      fms_sdi$dicc<-NA;
      fms_sdi$di<-NA;
      for(ni in 1:nfm_sdi){
        selfm<-subset(cub_sdi, idfustemed==fms_sdi$idfustemed[ni])
        i<-1;
        while(selfm$hi[i] < nhis[j]) i <- i + 1;
        i<-ifelse(i>1,i,i+1);
        fms_sdi$dicc[ni] = with(selfm, dicc[i] + (((hi[i] - nhis[j]) * (dicc[i - 1] - dicc[i])) / (hi[i] - hi[i - 1])));
        #if(nhis[j]!=1.3) fms_sdi$di[ni] = with(selfm, di[i] + (((hi[i] - nhis[j]) * (di[i - 1] - di[i])) / (hi[i] - hi[i - 1])));
        if(nhis[j]!=1.3) fms_sdi$di[ni] = fms_sdi$dicc[ni]-with(selfm,(dicc[i]-di[i])-((((dicc[i]-di[i])-(dicc[i-1]-di[i-1]))*(hi[i]-1.3))/(hi[i]-hi[i-1])))
      }
      cub<-rbind(cub, fms_sdi);
      cub<-cub[order(cub$idfustemed,cub$hi),];
      rm(fms_sdi,nfm_sdi,cub_sdi,selfm);
    }
  }
  rm(fms_cdi,nhis);

  ii<-is.na(cub$di);
  if(sum(ii)>0){
    if(comcasca==T){
      cub$di[ii]<-cub$dicc[ii];
    }else{
      cub<-cub[order(cub$idfustemed,cub$hi),];
      ii<-seq(1,nrow(cub))[cub$hi==1.3 & is.na(cub$di)];
      cub$di[ii]<-with(cub,dicc[ii]-(dicc[ii+1]-di[ii+1])-((((dicc[ii+1]-di[ii+1])-(dicc[ii-1]-di[ii-1]))*(hi[ii+1]-1.3))/(hi[ii+1]-hi[ii-1])));
    }
  }
  
  cub<-subset(cub,hi>=hcil_toco);
  
  if(padrao==2){
    daps<-subset(cub,hi==1.3,c('idfustemed','dicc'));
    names(daps)<-c('idfustemed','dap');
    cub<-merge(cub,daps);
    rm(daps);
  }
  
  volcub<-subset(cub, duplicated(idfustemed)==F, c('idfustemed','dap','ht'));
  selcub<-subset(cub,di>0,c('idfustemed','hi','di'));
  
  #Inserindo os diâmetros comerciais não mensurados e estimando os his
  rem_nprod<-F;
  if(min(dcoms)>dbase_ponta){
    dcoms<-c(dcoms,dbase_ponta);
    rem_nprod<-T
  }
  
  for(j in 1:length(dcoms)){
    voltoras<-parear_seqmed(selcub);
    ii<-voltoras$di1>=dcoms[j];
    if(sum(ii==F)>0){
      selvoltoras<-voltoras[ii,];
    }else{
      selvoltoras<-voltoras;
    }
    dimin_idfustemed<-with(selvoltoras, aggregate(list(dimin=di2), list(idfustemed=idfustemed), min));
    selvoltoras<-merge(selvoltoras, dimin_idfustemed, sort=F);
    
    #hi_dimin<-subset(selvoltoras, di1!=di2 & di2==dimin);
    hi_dimin<-subset(selvoltoras, di1!=di2 & di2==dimin & dimin!=dcoms[j]);
    #hi_dimin<-hi_dimin[order(hi_dimin$idfustemed, -hi_dimin$hi2),];
    #hi_dimin<-subset(hi_dimin, duplicated(idfustemed)==F);
    
    if(nrow(hi_dimin)>0){
      hi_dimin$hi<-with(hi_dimin,hi1+((di1-dcoms[j])*(hi2-hi1))/(di1-di2));
      hi_dimin$di<-dcoms[j];
      selcub<-rbind(selcub,hi_dimin[,c('idfustemed','hi','di')]);
    }
    selcub<-selcub[order(selcub$idfustemed,selcub$hi),];
    # for(i in 2:nrow(selcub)){
    #   if(selcub$idfustemed[i]==selcub$idfustemed[i-1] & selcub$di[i]>selcub$di[i-1]) selcub$di[i]<-selcub$di[i-1];
    # }
  }
  rm(dimin_idfustemed,selvoltoras,hi_dimin,cub);
  
  voltoras<-parear_seqmed(selcub);
  voltoras<-subset(voltoras,di2>=dbase_ponta);
  
  voltoras$gi1<-((pi*voltoras$di1^2)/40000);
  voltoras$gi2<-((pi*voltoras$di2^2)/40000);
  voltoras$vtora<-with(voltoras,((gi2+gi1)/2)*(hi2-hi1));
  
  nprod<-length(dcoms);

  for(j in 1:nprod){
    calc_vol_toras<-with(subset(voltoras, hi1>=htoco & di2>=dcoms[j]),aggregate(list(vcom=vtora),list(idfustemed=idfustemed),sum));
    names(calc_vol_toras)<-c('idfustemed',paste('vprod_',dcoms[j],sep=''));
    volcub<-merge(volcub,calc_vol_toras, by='idfustemed', all.x=T, sort=F);
  }
  
  volcub[is.na(volcub)]<-0;
  
  if(sum(voltoras$hi2<=htoco)>0){
    calc_vol_toco<-with(subset(voltoras, hi1<=htoco),aggregate(list(vtoco=vtora),list(idfustemed=idfustemed),sum));
    volcub<-merge(volcub,calc_vol_toco, by='idfustemed', all.x=T, sort=F);
    rm(calc_vol_toco);
  }else{
    volcub$vtoco<-0;
  }
  
  calc<-aggregate(list(dcil=selcub$di),list(idfustemed=selcub$idfustemed),max);
  volcub<-merge(volcub,calc, by='idfustemed', sort=F);
  calc<-aggregate(list(hponta=voltoras$hi2),list(idfustemed=voltoras$idfustemed),max);
  volcub<-merge(volcub,calc, by='idfustemed', sort=F);
  
  if(sum(voltoras$di1<=dcoms[nprod])>0){
    calc_vol_ponta<-with(subset(voltoras, di1<=dcoms[nprod]),aggregate(list(vponta=vtora),list(idfustemed=idfustemed),sum));
    volcub<-merge(volcub,calc_vol_ponta, by='idfustemed', all.x=T, sort=F);
    rm(calc_vol_ponta);
  }else{
    volcub$vponta<-0;
  }
  rm(calc_vol_toras,calc,ii,j,nfm);
  
  volcub[is.na(volcub)]<-0;
  volcub$vtoco<-with(volcub,vtoco+((pi*dcil^2)/40000)*hcil_toco);
  volcub$vponta<-with(volcub,vponta+((pi*dbase_ponta^2)/40000)*(ht-hponta)/3);
  volcub$dcil<-NULL;
  volcub$hponta<-NULL;
  
  volcub$vcilcc<-with(volcub, ht*pi*(dap^2)/40000);
  volcub$vt<-volcub$vtoco+volcub$vponta+volcub[,paste('vprod_',dcoms[nprod],sep='')];
  
  if(rem_nprod==T) volcub[,paste('vprod_',dcoms[nprod],sep='')]<-NULL;

  if(comcasca==T){
    volcub$vtcc<-volcub$vt;
    volcub$ffcc<-volcub$vtcc/volcub$vcilcc;
  }else{
    volcub$vtsc<-volcub$vt;
    volcub$ffsc<-volcub$vtsc/volcub$vcilcc;
  }
  volcub<-volcub[order(volcub$idfustemed),];
  volcub$vt<-NULL;
  names(volcub)[1:length(bknames)]<-bknames;
  rm(selcub);
  return(volcub)
}
