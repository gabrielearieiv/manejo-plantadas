# Criado em:     2019-09-19                                                          
# Modificado em: 2019-09-19                                                                                                                    

#' @title Modificar valores de um vetor
#' 
#' @description  Modificar valores de um vetor
#' 
#' @usage v_from_to(vvalues,vselvalues,vnewvalues)
#'
#' @param vvalues    'Vetor' de observações \cr
#' @param vselvalues 'Vetor' de observações a serem localizadas no vetor vvalues
#' @param vnewvalues 'Vetor' com as novas observações a serem substituídas no vetor vvalues
#' @return 'Vetor' de observações 'vvalues' com as respectivas atualizações definidas em vnewvalues 
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.com.br},\cr
#' Monica Fabiana Bento Moreira \email{engagri@@yahoo.com.br}.
#' @keywords rename
#' @rdname v_from_to
#' @export

v_from_to<-function(vvalues,vselvalues,vnewvalues){
  if(!is.vector(vvalues)) stop("O objeto 'vvalues' deve ser um vetor", call. = FALSE);
  if(!is.vector(vselvalues)) stop("O objeto 'vselvalues' deve ser um vetor", call. = FALSE);
  if(!is.vector(vnewvalues)) stop("O objeto 'vnewvalues' deve ser um vetor", call. = FALSE);
  
  if(length(vselvalues) != length(vnewvalues)) stop("Os vetores 'vselvalues' e 'vnewvalues' devem possuir o mesmo número de informações", call. = FALSE);

  vvalues<-data.frame(ni=seq(length(vvalues)),vv=vvalues,stringsAsFactors = F);
  vselvalues<-data.frame(vv=vselvalues,vn=vnewvalues,stringsAsFactors = F);
  vvalues<-merge(vvalues,vselvalues, by='vv',all.x=T,sort=F);
  ii<-!is.na(vvalues$vn);
  if(sum(ii)>0){
    vvalues$vv[ii]<-vvalues$vn[ii]
  }
  return(as.vector(vvalues$vv[order(vvalues$ni)]))
}
