#' @title Dados coletados de um inventario florestal - Povoamento seminal de
#' Eucalyptus grandis - ACS
#' 
#' @description Dados coletados em um inventário florestal de Eucalyptus grandis no Sul do
#' Estado de São Paulo.  O plano amostral adotado foi a amostragem casual
#' simples. \cr O plantio foi realizado utilizando mudas provenientes de
#' sementes, fato que, colaborou para o aumento da heterogeneidade do
#' povoamento.
#' 
#' @name invflor2
#' @docType data
#' @format data.frame: 6068 obs. de 12 variáveis:\cr ..$ estrato......: [int]
#' Número do estrato\cr ..$ talhao.......: [int] Talhão\cr ..$ area.........:
#' [num] Área do talhão [ha]\cr ..$ dataplantio..: [date] Data de plantio\cr
#' ..$ datamedicao..: [date] Data de medição\cr ..$ parcela......: [num] Número
#' da parcela\cr ..$ areaparc.....: [num] Área da parcela [m²]\cr ..$
#' arv..........: [int] Número da árvore\cr ..$ cat..........: [int] Número da
#' categoria\cr ..$ desccat......: [char] Descrição da categoria\cr ..$
#' dap..........: [num] Diâmetro à 1,3 metros do solo [cm]\cr ..$
#' ht...........: [num] Altura total [m]\cr
#' @keywords inventário
NULL