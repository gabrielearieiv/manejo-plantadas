# Criado em:     2011-06-17                                                          *
# Modificado em: 2012-06-06                                                          *


#' @title Valor presente considerando ciclos infinitos
#' 
#' @description  Analise economica - Valor presente considerando ciclos infinitos
#' 
#' @param rc 'data frame'\cr
#'  ..$ [[1]]:    Período de ocorrência da receita ou custo. Ex: ano, mês, etc.\cr
#'  ..$ [[2]]:    Receita ou Custo. Obs: Os valores serão considerados em módulo
#' @param tj Taxa de juros(anual, mensal, etc.). Default(0.1)
#' @return Valor presente considerando ciclos infinitos
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.br},\cr
#' Monica F. B. M. Thiersch \email{engagri@@yahoo.com.br}.
#' @seealso avecon
#' @keywords vpinf
#' @rdname vpinf
#' @export
vpinf<-function (rc, tj){
  if (missing(tj)) tj <- 0.1;
  rc <-rc[rc[,2]!=0 & is.na(rc[,2])==F, c(1,2)];
  rc[,2]<-abs(rc[,2]);
  percap<-max(rc[,1]);
  return ((vp(rc,tj) * ((1 + tj) ^ percap)) / (((1 + tj) ^ percap) - 1));
}
