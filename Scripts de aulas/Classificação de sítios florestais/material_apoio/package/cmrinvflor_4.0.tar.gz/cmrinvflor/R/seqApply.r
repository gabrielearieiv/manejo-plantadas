# Criado em:     2020-07-10                                                          
# Modificado em: 2020-08-22                                                          

#' @title Apply a function to sequential parts of a data series
#' @description Uma função genérica para aplicar uma função em partes sequênciais, com ou sem sobreposição, de uma série de dados.
#' @param dat 'vector','data.frame' ou 'matrix'
#' @param fun Função para ser aplicada
#' @param ... Argumentos opcionais de fun
#' @param by Incremento da sequência
#' @param overlap Sobreposição do passo
#' @param accumulate Acumular dados.  Será desconsiderado o parâmetro "overlap"
#' @param initialDataAccumulation Número inicial de informações da primeira sequência de dados caso "accumulate=T".
#' @return Objeto igual ao produzido pela função \code{\link[base]{lapply}}
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.br},\cr 
#' Monica F. B. M. Thiersch \email{engagri@@yahoo.com.br}.
#' @rdname seqApply
#' @export
seqApply<-function(dat,fun,...,by=1,overlap=1,accumulate=F,initialDataAccumulation=by){
  if(overlap>by) stop('The "overlap" parameter must be less than or equal to the "by" parameter!', call.=F);
  overlap=-overlap;
  nobs<-ifelse(inherits(dat,'data.frame')|inherits(dat,'matrix'),nrow(dat),length(dat))
  if(!accumulate){
    r1<-seq(from=1,to=nobs-by,by=overlap+by+1);
    r2<-seq(from=1+by,to=nobs,by=overlap+by+1);
  }else{
    r2<-seq(from=initialDataAccumulation,to=nobs,by=by);
    r1<-rep(1,length(r2));
  }

  f1<-function(r) seq(from=r[[1]],to=r[[2]]);
  rs<-by(list(r1,r2),1:length(r1),f1);
  
  if(inherits(dat,'data.frame')|inherits(dat,'matrix')){
    f2<-function(rs,dat,fun) fun(dat[rs,],...)
  }else{
    f2<-function(rs,dat,fun) fun(dat[rs],...)
  }
  return(lapply(rs,f2,dat,fun));
}
#fun<-function(...) sum(..., na.rm=T); #Redefinindo parâmetro default
