# Criado em:     2019-10-03
# Modificado em: 2019-12-09

#' @title Calculo das estatisticas da amostragem casual estratificada
#' 
#' @description  Cálculo das estatísticas da amostragem casual estratificada
#' 
#' @usage estats_ace(estrato, amostra, sig=5, fc_dim=1)
#' 
#' @param  estrato 'data frame'\cr
#'..$ idestrato: Identificacão do estrato\cr
#'..$ dimensao: Dimensão do estrato\cr
#' @param  amostra 'data frame'\cr
#'..$ idestrato: Identificação do estrato\cr
#'..$ idamostra: Identificação da amostra\cr
#'..$ dimensao: Dimensão da amostra\cr
#'..$ vary: Variável de interesse\cr
#' @param sig: Nível de significância em porcentagem (0 a 100). 
#' @param fc_dim: Fator de conversão da dimensão da amostra para a mesma unidade da dimensão do estrato. 
#' 
#' @return 
#' 'lista'\cr 
#' ..$ ymstr: Média estratificada\cr 
#' ..$ s2ymstr: Variância da média estratificada\cr 
#' ..$ gle: Grau de liberdade efetivo\cr 
#' ..$ dimensao: Dimensão da população\cr
#' ..$ np: Número de unidades amostrais cabíveis na população\cr 
#' ..$ na: Número de unidades amostrais selecionadas\cr 
#' ..$ eunid: Erro amostral na unidade da variável de interesse\cr 
#' ..$ eperc: Erro amostral em percentagem\cr 
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.br},\cr 
#' Monica Fabiana Bento Moreira \email{engagri@@yahoo.com.br}.
#' @keywords ace
#' @rdname estats_ace
#' @export
estats_ace<-function(estrato, amostra, sig=5, fc_dim=1){
  if(sum(c('idestrato','dimensao') %in% names(estrato))!=2){
    names(estrato)[1:2]<-c('idestrato','dimensao')
  }
  if(sum(c('idestrato','idamostra','dimensao','vary') %in% names(amostra))!=4){
    names(amostra)[1:4]<-c('idestrato','idamostra','dimensao','vary');
  }
  estrato<-aggregate(
    list(dimensao=estrato$dimensao),
    list(idestrato=estrato$idestrato),
    sum
  );

  sig<-1-(sig/200);
  amostra$dimensao<-amostra$dimensao*fc_dim;
  
  calc<-with(amostra,aggregate(list(dim_ua=dimensao,vary=vary),
                               list(idestrato=idestrato),
                               mean, na.rm=T));
  estrato<-merge(estrato,calc);
  
  #Numero de parcelas por estrato
  calc<-with(amostra,aggregate(list(anj=idamostra),list(idestrato=idestrato),length));
  estrato<-merge(estrato,calc);
  
  #Variancia e desvio padrao por estrato
  calc<-with(amostra,aggregate(list(s2yest = vary),list(idestrato=idestrato),var,na.rm=T));
  calc$syest<-sqrt(calc$s2yest);
  
  estrato<-merge(estrato,calc);
  
  #Parcelas cabiveis por estrato
  estrato$pnj<-estrato$dimensao/estrato$dim_ua;

  #Dimensao total(dimtot), numero de amostras(AN) e
  #n. de parcelas cabiveis(PN) em todos os estratos
  
  estrato$dim_tot=sum(estrato$dimensao);
  estrato$an=sum(estrato$anj);
  estrato$pn=sum(estrato$pnj);
  
  #Peso de cada estrato
  estrato$pwj<-estrato$dimensao/estrato$dim_tot;
  
  #Media estratificada
  ymstr<-with(estrato,sum(pwj*vary));
  #Variancia da media estratificada
  s2ymstr<-with(estrato,sum((s2yest/anj)*(pwj^2))-sum((pwj*s2yest)/pn));
  
  #Calculo dos graus de liberdade estratificado
  estrato$calcgl=with(estrato,(pnj*(pnj-anj))/anj);
  
  gle<-with(estrato,(sum(((pnj*(pnj-anj))/anj)*s2yest)^2)/sum(((((pnj*(pnj-anj))/anj)*s2yest)^2)/(anj-1)));

  eunid=qt(sig,gle)*sqrt(s2ymstr);
  eperc=eunid/ymstr*100;

  return(
    list(
         ymstr=ymstr,
         s2ymstr=s2ymstr,
         gle=gle,
         dimensao=estrato$dim_tot[1],
         np=estrato$pn[1],
         na=estrato$an[1],
         eunid=eunid,
         eperc=eperc
    )
  )
}
