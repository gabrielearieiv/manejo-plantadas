#' @title Funcoes e dados de apoio ao livro Inventario Florestal
#' 
#' @description  Coletânea de funções e dados de apoio ao livro Inventario Florestal
#' 
#' \tabular{ll}{ Package: \tab cmrinvflor\cr 
#' Type: \tab Package\cr 
#' Version: \tab 4.0\cr 
#' Depends: \tab R (>= 4.0.0) \cr
#' License: \tab GPL Version 2 or later\cr 
#' LazyLoad: \tab yes\cr 
#' LazyData: \tab yes}
#' 
#' @name cmrinvflor-package
#' @aliases cmrinvflor
#' @docType package
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.br},\cr 
#' Monica F. B. M. Thiersch \email{monicathiersch@@ufscar.br}.\cr
#' Maintainer: Claudio Roberto Thiersch <crthiersch@@ufscar.br>
NULL