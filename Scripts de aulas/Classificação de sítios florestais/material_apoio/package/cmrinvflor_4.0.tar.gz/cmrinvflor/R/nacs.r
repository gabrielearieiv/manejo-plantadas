# Criado em:     2005-02-05                                                          *
# Modificado em: 2009-06-11                                                          *

#' @title Calculo da intensidade amostral para a amostragem casual simples
#' 
#' @description   Estimativa da intensidade amostral para a amostragem casual simples fazendo
#' o cálculo e recálculo até a estabilização do número de amostras.
#'
#' @usage nacs(vy, eperc=10, sig=5, N=Inf)
#'   
#' @param vy Vetor de dados
#' @param eperc Erro percentual máximo esperado para a amostra.
#' @param sig Nível de significância em porcentagem (0 a 100).
#' @param N Número total de parcelas cabíveis na área.
#' @return Número de amostras estimado
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.br},\cr 
#' Monica Fabiana Bento Moreira \email{engagri@@yahoo.com.br}.
#' @keywords nacs
#' @rdname nacs
#' @export
nacs<-function(vy,eperc=10,sig=5,N=Inf){

  sig<-sig/200;
  vy<-as.vector(vy);
  n1 <- length(vy);
  if (n1 > 1){
    cv <- sd(vy)/mean(vy)*100;
    t <- qt(1-sig,n1-1);
    n1 <- round(((t^2)*(cv^2))/((eperc^2)+((t^2)*(cv^2)/N)));
    if(n1<3){n1=3};
    t <- qt(1-sig,n1-1);
    n2 <- round(((t^2)*(cv^2))/((eperc^2)+((t^2)*(cv^2)/N)));
    if(n2<3){n2=3};
    if (n2 == n1){
        n3 <- n2;
    }else{
        aux <- 0;
        while (aux == 0){
          t <- qt(1-sig,n2-1);
          n3 <- round(((t^2)*(cv^2))/((eperc^2)+((t^2)*(cv^2)/N)));
          if(n3<3){n3=3};
          if ((n3 == n2)|(n3 == n1)){
            aux <- 1;
          } else{
            n1 <- n2;
            n2 <- n3;
          }
        }
    }
    res <- n3;
  }else{
    res <- 0;
  }
  return(res);
}
