# Criado em:     2008-11-13                                                              
# Modificado em: 2019-09-24                                                          

#' @title Estimativa dos multiplos produtos por arvore utilizando o polinomio de quinto grau - Sentido base topo
#' 
#' @description Estimativa dos múltiplos produtos por árvore utilizando o polinômio de quinto grau - Sentido base topo
#' 
#' @param dfarv 'data.frame'\cr
#'  ..$ idestcoef: Chave primária da tabela estrato coeficiente\cr
#'  ..$ idfustemed:   Chave primária da tabela fuste medição\cr
#'  ..$ dap: Diâmetro a 1.3 metros do solo\cr
#'  ..$ htre: Altura total real ou estimada\cr
#'  ..$ htest: Altura total estimada\cr
#'  ..$ haprov_total
#' @param dfcoef 'data.frame'\cr
#'  ..$ idestcoef: Chave primária da tabela estrato coeficiente\cr
#'  ..$ b0:  Coeficiente b0\cr 
#'  ..$ b1:  Coeficiente b1\cr
#'  ..$ b2:  Coeficiente b2\cr
#'  ..$ b3:  Coeficiente b3\cr
#'  ..$ b4:  Coeficiente b4\cr
#'  ..$ b5:  Coeficiente b5\cr
#' @param vprod 'matriz':	n produtos e 4 parâmetros:\cr
#'  ..$ Diâmetro mínimo do produto (cm)\cr
#'  ..$ Comprimento do produto (m)\cr 
#'  ..$ Comprimento mínimo aceito para a última tora (m)\cr
#'  ..$ Altura do toco(m)
#' @param nomprod 'vetor' \cr
#'  ..$ nomes dos produtos
#' @param subseq  Produtos subsequentes: Sim (1) ou não (0)
#' @return calcarv 'matriz'\cr 
#' ..$ idfustemed: Chave primária da tabela fuste medição\cr
#' ..$ ntorasi_p: Número de toras por produto\cr 
#' ..$ sdtorasi_p: Soma dos  diâmetros centrais das toras por produto\cr 
#' ..$ dmini_p: diâmetro mínimo da  ponta fina por produto\cr 
#' ..$ toramini_p: Comprimento da última tora por produto\cr 
#' ..$ vtocoi_p: Volume do toco por produto\cr 
#' ..$ vprodi_p: Volume por produto\cr 
#' ..$ vti Volume total (Com ou sem casca dependendo dos coeficientes)\cr 
#' *_p Nome do produto - O número de colunas dependerá do número de produtos.
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.br},\cr 
#' Monica Fabiana Bento Moreira \email{engagri@@yahoo.com.br}.
#' @keywords Afilamento Taper
#' @rdname multprodarvbt5grau
#' @export
multprodarvbt5grau<-function(dfarv, dfcoef, vprod, nomprod, subseq){

  dfarv$htafil<-dfarv$htre;
  ii<-(dfarv$haprov_total==0 & dfarv$htre<dfarv$htest);
  dfarv$htafil[ii]<-dfarv$htest[ii];
  ii<-dfarv$htafil<1.3;
  if (sum(ii)>0){
    dfarv<-dfarv[ii==FALSE,];
  }

  if (is.vector(vprod)) vprod<-t(vprod);
  nprod<-nrow(vprod);
  if(subseq==1 & nprod>1){
    ii<-order(vprod[,1], decreasing = TRUE);
    vprod<-vprod[ii,];
    nomprod<-nomprod[ii];
  }

  nl<-nrow(dfarv); #Número de observações
  ncols<-ncol(dfarv);

  dados<-merge(dfarv,dfcoef, by.x="idestcoef", by.y="idestcoef", sort = FALSE);

  rm(dfarv, dfcoef);

  vnt<-matrix(NA,nl,5);
  #vnt[i,1] = Número de toras de um determinado produto
  #vnt[i,2] = 0 ou 1 - Define se já foi calculado ou não o comprimento aproveitável da última seção de um determinado produto
  #vnt[i,3] = Comprimento aproveitável da última seção de um determinado produto
  #vnt[i,4] = Diâmetro mínimo final de aproveitamento
  #vnt[i,5] = Soma dos diâmetros centrais das toras

  vest<-matrix(NA,nl,1);
  vhd<-matrix(NA,nl,1);
  vtoco<-matrix(NA,nl,1);
  vntoras<-matrix(NA,nl, nprod);
  vntoras[,]<-0;
  vsdtoras<-matrix(NA,nl, nprod);
  vsdtoras[,]<-0;
  vhif<-matrix(NA,nl, nprod);
  vhif[,]<-0;
  vdmin<-matrix(NA,nl, nprod);
  vdmin[,]<-0;
  vvoltoras<-matrix(NA,nl, nprod + 1);
  vvoltoras[,]<-0;

  dados$c0<-dados$b0;
  dados$c1<-with(dados,b1/htafil);
  dados$c2<-with(dados,b2/(htafil ^ 2));
  dados$c3<-with(dados,b3/(htafil ^ 3));
  dados$c4<-with(dados,b4/(htafil ^ 4));
  dados$c5<-with(dados,b5/(htafil ^ 5));

  if(subseq==0){
    vtocos<-matrix(NA,nl, nprod);
    vtocos[,]<-0;
    htoco<-vprod[1,4];
    vtoco[,1]<-with(dados,v5grau(vprod[1,4],dap,c0,c1,c2,c3,c4,c5));
    for (np in 1:nprod){
       #Cálculo do número de toras por produto
       vnt[,]<-0;
       vest[,1]<-0;
       vhd[,1] <-  vprod[np,4];
       if(htoco!=vprod[np,4]){
          htoco=vprod[np,4];
          vtoco[,1]<-with(dados,v5grau(htoco,dap,c0,c1,c2,c3,c4,c5));
       }
       limite <- vprod[np, 1];  #Diâmetro mínimo
       #vnt[i,1] = Número de toras de um determinado produto
       #vnt[i,2] = 0 ou 1 - Define se já foi calculado ou não o comprimento aproveitável da última seção de um determinado produto
       #vnt[i,3] = Comprimento aproveitável da última seção de um determinado produto
       #vnt[i,4] = Diâmetro mínimo final de aproveitamento
       aux <- 0;  #aux  define a realização ou não do cálculo do número de toras de um determinado produto para todas as árvores
       while(aux==0){
         aux <- 1;
         for (i in 1:nl){
           if (vnt[i, 2] == 0){
             if (dados$htre[i] >= (htoco + vprod[np, 2])){
               #Rotina para árvores maiores que o comprimento desejado para as toras
               if((vhd[i, 1] + vprod[np, 2]) <= dados$htre[i]){
                   hc = vhd[i, 1] + (vprod[np, 2]/2);
                   vhd[i, 1] = vhd[i, 1] + vprod[np, 2];
                   di=with(dados[i,],d5grau(vhd[i, 1],dap,htafil,b0,b1,b2,b3,b4,b5));
                   if (di >= limite){
                     vnt[i, 1] = vnt[i, 1] + 1;
                     vnt[i, 4] = di;
                     vnt[i, 5] = vnt[i, 5] + with(dados[i,],d5grau(hc,dap,htafil,b0,b1,b2,b3,b4,b5));
                     aux = 0;
                   }else{
                      vnt[i, 2] = 1;
                      if (vprod[np, 3] == vprod[np, 2]){
                         vnt[i, 3] = vprod[np, 2];
                      }else{
                         inc<-vprod[np, 3];
                         vhd[i, 1] = vhd[i, 1] - vprod[np, 2];
                         hc = vhd[i, 1];
                         hi = vhd[i, 1] + inc;
                         if (hi <= dados$htre[i]){
                            di = limite;
                            while (di >= limite & hi<=dados$htre[i]){
                              di=with(dados[i,],d5grau(hi,dap,htafil,b0,b1,b2,b3,b4,b5));
                              if(di >= limite){
                                  inc<-0.3;
                                  hi = hi + inc;
                                  vnt[i, 4] = di;
                               }
                            }
                            hi = hi - inc;
                            if (inc == vprod[np, 3]){
                                vnt[i, 3] = vprod[np, 2];
                            }else{
                                vnt[i, 1] = vnt[i, 1] + 1;
                                vnt[i, 3] = hi-vhd[i, 1];
                                hc = hc + (vnt[i, 3]/2);
                                vnt[i, 5] = vnt[i, 5] + with(dados[i,],d5grau(hc,dap,htafil,b0,b1,b2,b3,b4,b5));
                            }
                         }else{
                            if (vn[i,1]>0){
                              vnt[i, 3] = vprod[np, 2];
                            }else{
                              vnt[i, 3] = 0;
                            }
                         }
                      }
                   }
               }else{
                  vnt[i, 2] = 1;
                  inc<-vprod[np, 3];
                  hc = vhd[i, 1];
                  hi = vhd[i, 1] + inc;
                  if (hi <= dados$htre[i]){
                     di = limite;
                     while (di >= limite & hi<=dados$htre[i] & di != 0){
                       di=with(dados[i,],d5grau(hi,dap,htafil,b0,b1,b2,b3,b4,b5));
                       if(di >= limite){
                           inc<-0.3;
                           hi = hi + inc;
                           vnt[i, 4] = di;
                        }
                     }
                     hi = hi - inc;
                     if (inc == vprod[np, 3]){
                         vnt[i, 3] = vprod[np, 2];
                     }else{
                         vnt[i, 1] = vnt[i, 1] + 1;
                         vnt[i, 3] = hi-vhd[i, 1];
                         hc = hc + (vnt[i, 3]/2);
                         vnt[i, 5] = vnt[i, 5] + with(dados[i,],d5grau(hc,dap,htafil,b0,b1,b2,b3,b4,b5));
                     }
                  }else{
                     vnt[i, 3] = vprod[np, 2];
                  }
               }
             }else{
               vnt[i, 2] <- 1;
               if (dados$htre[i] >= (htoco + vprod[np, 3])){
                 #Rotina para árvores menores que o comprimento desejado para as toras
                 hc <- vhd[i, 1];
                 hi <- vhd[i, 1] + vprod[np, 3];
                 di <- limite;
                 while ((di >= limite) & (hi < dados$htre[i])){
                    di<-with(dados[i,],d5grau(hi,dap,htafil,b0,b1,b2,b3,b4,b5));
                    if(di >= limite){
                        hi <- hi + 0.3;
                        vnt[i, 4] <- di;
                    }
                 }
                 hi <- hi - (vhd[i, 1] + 0.3);
                 if (hi < vprod[np, 3]){
                    vnt[i, 3] = vprod[np, 2];
                 }else{
                    vnt[i, 1] = vnt[i, 1] + 1;
                    vnt[i, 3] = hi;
                    hc = hc + (vnt[i, 3]/2);
                    vnt[i, 5] = vnt[i, 5] + with(dados[i,],d5grau(hc, dap, htafil, b0,b1,b2,b3,b4,b5));
                 }
               }
             }
           }
         }
       }

       for (i in 1:nl){
          vtocos[i, np] = vtoco[i];
          if(vnt[i, 1] > 0){
              vntoras[i, np] = vnt[i, 1];
              vsdtoras[i, np] = vnt[i, 5];
              vhif[i, np] = vnt[i, 3];
              vdmin[i, np] = vnt[i, 4];
              vhd[i, 1] =  vprod[np,4] + ((vnt[i, 1] * vprod[np, 2]) - (vprod[np, 2] - vnt[i, 3]));
              vest[i, 1]<-with(dados[i,],v5grau(vhd[i, 1],dap,c0,c1,c2,c3,c4,c5));
              if(vest[i,1] > 0){
                  vvoltoras[i,np]=vest[i,1]-vtoco[i];
              }
          }
       }
    }

    #Cálculo dos volumes totais
    vvoltoras[, nprod + 1]<-with(dados,v5grau(htre,dap,c0,c1,c2,c3,c4,c5)); #Volume total
    calcarv<-as.matrix(cbind(dados$idfustemed,vntoras,vsdtoras,vdmin,vhif, vtocos, vvoltoras));

    nome<-c("idfustemed");
    for(i in 1:nprod){nome<-c(nome,paste("ntorasi",nomprod[i],sep=""))};
    for(i in 1:nprod){nome<-c(nome,paste("sdtorasi",nomprod[i],sep=""))};
    for(i in 1:nprod){nome<-c(nome,paste("dmini",nomprod[i],sep=""))};
    for(i in 1:nprod){nome<-c(nome,paste("toramini",nomprod[i],sep=""))};
    for(i in 1:nprod){nome<-c(nome,paste("vtocoi",nomprod[i],sep=""))};
    for(i in 1:nprod){nome<-c(nome,paste("vprodi",nomprod[i],sep=""))};
    nome<-c(nome, "vti");

    dimnames(calcarv)<-list(c(), nome);


  }else{

    vhvolac<-matrix(,nl, 2);
    vhvolac[,]<-0;
    vhd[, 1] = vprod[1,4];
    vhvolac[, 1] = vprod[1,4];
    vhvolac[, 2]<-with(dados,v5grau(vhvolac[,1],dap,c0,c1,c2,c3,c4,c5));
    vtoco[,1]<- vhvolac[, 2];

    for (np in 1:nprod){
       #Cálculo do número de toras por produto
       vnt[,]<-0;
       vest[,1]<-0;
       limite <- vprod[np, 1];  #Diâmetro mínimo
       aux = 0;  #aux  define a realização ou não do cálculo do número de toras de um determinado produto para todas as árvores
       while(aux==0){
         aux <- 1;
         for (i in 1:nl){
           if (vnt[i, 2] == 0){
             if((vhd[i, 1] + vprod[np, 2]) <= dados$htre[i]){
                 hc = vhd[i, 1] + (vprod[np, 2]/2);
                 vhd[i, 1] = vhd[i, 1] + vprod[np, 2];
                 di=with(dados[i,],d5grau(vhd[i, 1],dap,htafil,b0,b1,b2,b3,b4,b5));
                 if (di >= limite){
                   vnt[i, 1] = vnt[i, 1] + 1;
                   vnt[i, 4] = di;
                   vnt[i, 5] = vnt[i, 5] + with(dados[i,],d5grau(hc,dap,htafil,b0,b1,b2,b3,b4,b5));
                   aux = 0;
                 }else{
                    vnt[i, 2] = 1;
                    if (vprod[np, 3] == vprod[np, 2]){
                       vnt[i, 3] = vprod[np, 2];
                    }else{
                       inc<-vprod[np, 3];
                       vhd[i, 1] = vhd[i, 1] - vprod[np, 2];
                       hc = vhd[i, 1];
                       hi = vhd[i, 1] + inc;
                       if (hi <= dados$htre[i]){
                          di = limite;
                          while (di >= limite & hi<=dados$htre[i]){
                            di=with(dados[i,],d5grau(hi,dap,htafil,b0,b1,b2,b3,b4,b5));
                            if(di >= limite){
                                inc<-0.3;
                                hi = hi + inc;
                                vnt[i, 4] = di;
                             }
                          }
                          hi = hi - inc;
                          if (inc == vprod[np, 3]){
                              vnt[i, 3] = vprod[np, 2];
                          }else{
                              vnt[i, 1] = vnt[i, 1] + 1;
                              vnt[i, 3] = hi-vhd[i, 1];
                              hc = hc + (vnt[i, 3]/2);
                              vnt[i, 5] = vnt[i, 5] + with(dados[i,],d5grau(hc,dap,htafil,b0,b1,b2,b3,b4,b5));
                          }
                       }else{
                          vnt[i, 3] = vprod[np, 2];
                       }
                    }
                 }
             }else{
                vnt[i, 2] = 1;
                inc<-vprod[np, 3];
                hc = vhd[i, 1];
                hi = vhd[i, 1] + inc;
                if (hi <= dados$htre[i]){
                   di = limite;
                   while (di >= limite & hi<=dados$htre[i] & di != 0){
                     di=with(dados[i,],d5grau(hi,dap,htafil,b0,b1,b2,b3,b4,b5));
                     if(di >= limite){
                         inc<-0.3;
                         hi = hi + inc;
                         vnt[i, 4] = di;
                      }
                   }
                   hi = hi - inc;
                   if (inc == vprod[np, 3]){
                       vnt[i, 3] = vprod[np, 2];
                   }else{
                       vnt[i, 1] = vnt[i, 1] + 1;
                       vnt[i, 3] = hi-vhd[i, 1];
                       hc = hc + (vnt[i, 3]/2);
                       vnt[i, 5] = vnt[i, 5] + with(dados[i,],d5grau(hc,dap,htafil,b0,b1,b2,b3,b4,b5));
                   }
                }else{
                   vnt[i, 3] = vprod[np, 2];
                }
             }
           }
         }
       }

       for (i in 1:nl){
          if(vnt[i, 1] > 0){
              vntoras[i, np] = vnt[i, 1];
              vsdtoras[i, np] = vnt[i, 5];
              vhif[i, np] = vnt[i, 3];
              vdmin[i, np] = vnt[i, 4];
              hi = (vnt[i, 1] * vprod[np, 2]) - (vprod[np, 2] - vnt[i, 3]);
              vhvolac[i, 1] = vhvolac[i, 1] + hi;
              vest[i, 1]<-with(dados[i,],v5grau(vhvolac[i,1],dap,c0,c1,c2,c3,c4,c5));
              if(vest[i,1] > 0){
                  vvoltoras[i,np]=vest[i,1]-vhvolac[i,2];
                  vhvolac[i,2]=vest[i,1];
              }
          }
          vhd[i, 1] = vhvolac[i, 1];
       }
    }

    #Cálculo dos volumes totais
    vvoltoras[, nprod + 1]<-with(dados,v5grau(htre,dap,c0,c1,c2,c3,c4,c5)); #Volume total

    calcarv<-as.matrix(cbind(dados$idfustemed, vntoras, vsdtoras,vdmin,vhif, vtoco[,1], vvoltoras));

    nome<-c("idfustemed");
    for(i in 1:nprod){nome<-c(nome,paste("ntorasi",nomprod[i],sep=""))};
    for(i in 1:nprod){nome<-c(nome,paste("sdtorasi",nomprod[i],sep=""))};
    for(i in 1:nprod){nome<-c(nome,paste("dmini",nomprod[i],sep=""))};
    for(i in 1:nprod){nome<-c(nome,paste("toramini",nomprod[i],sep=""))};
    nome<-c(nome, "vtocoi");
    for(i in 1:nprod){nome<-c(nome,paste("vprodi",nomprod[i],sep=""))};
    nome<-c(nome,"vti");

    dimnames(calcarv)<-list(c(), nome);
  }
   return(calcarv);
}
