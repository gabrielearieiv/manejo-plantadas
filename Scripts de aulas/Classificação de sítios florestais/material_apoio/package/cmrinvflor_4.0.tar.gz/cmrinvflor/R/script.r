# Criado em:     2020-08-20                                                          
# Modificado em: 2022-03-27         

#' @title Generate script
#' @description Esta função visa ajudar a criar e visualizar scripts' 
#' @param ... Um ou mais vetores de texto
#' @param input 'NULL' or 'inputScript' or 'list' or 'data.frame' or 'numeric'\cr 
#' ..inputScript \cr
#' ....[[1]] \cr
#' ......$variable_name:  name \cr
#' ......$variable_value:  value \cr
#' ......$evaluate: 'boolean' Aplicar expressão (T) ou Substituir valores (F). \cr
#' ....[[n]] \cr
#' ......$variable_name:  name \cr
#' ......$variable_value:  value \cr
#' ......$evaluate: 'boolean' Aplicar expressão (T) ou Substituir valores (F). \cr
#' ..list \cr
#' ....$variable_1: value \cr
#' ....$variable_2: value \cr
#' ....$variable_n: value \cr
#' ..data.frame \cr
#' ....$variable_name \cr
#' ....$variable_value \cr
#' ..numeric\cr
#' ....$variable_value (names = variable_name) \cr
#' @param tags Tags para identificação dos trechos a serem avaliados.
#' @param other_replacements 'list' Outras substituições.
#' @param envir Objeto igual ao utilizado pela função \code{\link[base]{eval}}
#' @param collapse Objeto igual ao utilizado pela função \code{\link[base]{paste}}
#' @param con Objeto igual ao utilizado pela função \code{\link[base]{readLines}} caso is.null(vtext)
#' @param encoding Objeto igual ao utilizado pela função \code{\link[base]{readLines}} caso is.null(vtext)
#' @return Vetor de expressões avaliadas
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.br},\cr 
#' Monica F. B. M. Thiersch \email{engagri@@yahoo.com.br}.
#' @examples vtext<-'a<<a>> e b<<b>>' \cr
#' input=list(list(name='a',value=1,evaluate=F),list(name='b',value=2,evaluate=F)); class(input)='inputScript'\cr
#' input=list(a=1,b=2)\cr
#' input=data.frame(variable=c('a','b'), value=c(1,2))\cr
#' input=structure(c(1,2),.Names=c('a','b'))\cr
#' vtext<-'<<a>>+<<b>>' \cr
#' script(vtext,input=input,tags=c('<<','>>'))\cr\cr
#' input=list(a=1,b=-2)\cr
#' script(vtext,input=input,tags=c('<<','>>'),other_replacements=list(list('+-','-')))
#' a=1;b=-2;script(vtext,input=NULL,tags=c('<<','>>'),other_replacements=list(list('+-','-')))
#' @rdname script
#' @export

script<-function(..., input=NULL, tags=NULL, other_replacements=NULL, envir = parent.frame(), 
                 collapse='', con=NULL, encoding=getOption('encoding')){
  vtext<-c(...)
  #print(vtext)
  if(is.null(vtext))  vtext<-readLines(con, encoding=encoding)
  if(!is.null(tags) | !is.null(other_replacements)){
    fgsub<-function(vtexti, new_input){
      for(i in 1:length(new_input)) vtexti<-finput(new_input[[i]], vtexti)
      return(vtexti)
    }
    finput<-function(new_input_i, vtexti) gsub(new_input_i$tag, new_input_i$value, vtexti, fixed = T)
  }
  if(!is.null(tags)){
    if(!is.null(input)){
      if(inherits(input,'list')){
        #f<-function(x) list(name=names(x), value=x[[1]], evaluate=grepl(tags[1],x,fixed=T))
        #f<-function(x) list(name=names(x), value=x[[1]], evaluate=F)
        #input<-lapply(split(input,1:length(input)),f)
        f<-function(x){
          if(length(x[[1]])==1){
            res<-list(list(name=names(x), value=x[[1]], evaluate=F))
          }else{
            fv<-function(i,xi,name) list(name=paste0(name,'[',i,']'), value=xi[i], evaluate=F)
            res<-lapply(1:length(x[[1]]),fv,x[[1]],names(x))
          }
          return(res)
        }
        input<-Reduce('c',lapply(split(input,1:length(input)),f))
      }else{
        if(inherits(input,'data.frame')){
          #f<-function(x) list(name=x[[1]], value=x[[2]], evaluate=grepl(tags[1],x[[2]],fixed=T))
          f<-function(x) list(name=x[[1]], value=x[[2]], evaluate=F)
          input<-lapply(split(input,1:nrow(input)),f)
        }
        if(inherits(input,'numeric')){
          #f<-function(x) list(name=names(x), value=x[[1]], evaluate=grepl(tags[1],x[[1]],fixed=T))
          f<-function(x) list(name=names(x), value=x[[1]], evaluate=F)
          input<-lapply(split(input,1:length(input)),f)
        }
      }
      ii<-Reduce('c',lapply(input,function(x,tags) {x$evaluate | grepl(tags[1],x[[2]],fixed=T)}, tags))
      i_evaluate<-(1:length(input))[ii];
      i_not_evaluate<-(1:length(input))[!ii];
      
      #fnew_input<-function(x,tags) list(tag=paste0(tags[1],x$name,tags[2]), value=x$value)
      fnew_input<-function(x,tags){
        if(x$evaluate){
          new_input<-list(tag=paste0(tags[1],x[[1]],tags[2]), value=eval(parse(text=x[[2]])),envir=envir)
        }else{
          new_input<-list(tag=paste0(tags[1],x[[1]],tags[2]), value=x[[2]])
        }
        return(new_input)
      }
      input_not_evaluate<-NULL
      input_evaluate<-NULL
      
      if(length(i_not_evaluate)>0)  input_not_evaluate<-lapply(input[i_not_evaluate],fnew_input,tags)
  
      if(length(i_evaluate)>0){
        input_evaluate<-input[i_evaluate]
        if(length(input_not_evaluate)>0){
          fevaluate<-function(x, tags, input_not_evaluate) {
            if(grepl(tags[1],x[[2]], fixed=T)) x[[2]]<-fgsub(x[[2]], input_not_evaluate)
            return(x)
          }
          input_evaluate<-lapply(input_evaluate,fevaluate,tags,input_not_evaluate)
        }else{
          stop('The "input" parameter incomplete!',call.=F);
        }
        input_evaluate<-lapply(input_evaluate,fnew_input,tags)
      }
      new_input<-c(input_evaluate,input_not_evaluate)
      vtext<-Reduce('c',lapply(vtext,fgsub,new_input));
    }else{
      f2<-function(x){
        tag=x[[1]]
        value=gsub(tags[1],'',x[[1]],fixed=T)
        value=gsub(tags[2],'',value,fixed=T)
        value=eval(parse(text=value),envir=envir)
        return(list(tag=tag,value=value))
      }
      f1<-function(vtexti){
        if(grepl(tags[1],vtexti,fixed=T)){
          it1<-as.vector(gregexpr(tags[1],vtexti,fixed=T)[[1]], mode = 'integer')
          it2<-as.vector(gregexpr(tags[2],vtexti,fixed=T)[[1]], mode = 'integer')
          it2<-it2-1+nchar(tags[2])
          pair<-lapply(it1,function(x,y) c(x,min(y[y>x])),it2)
          input<-lapply(pair,function(x) substr(vtexti,x[1],x[2]))
          input<-lapply(input,f2)
          vtexti<-fgsub(vtexti,input)
        }
        return(vtexti)
      }
      vtext<-Reduce('c',lapply(vtext,f1))
    }
  }
  if(!is.null(other_replacements)){
    f<-function(x) {names(x)<-c('tag','value'); return(x)}
    other_replacements<-lapply(other_replacements,f)
    vtext<-Reduce('c',lapply(vtext,fgsub,other_replacements));
  }
  vtext<-paste(vtext, sep='', collapse = collapse)
  if(!is.null(collapse)) vtext<-new("script", vtext)
  return(vtext)
}
setClass("script", contains = "character")
setMethod("show", "script", function(object) {
  cat(paste0("<script>\n", object@.Data), "\n")
})
