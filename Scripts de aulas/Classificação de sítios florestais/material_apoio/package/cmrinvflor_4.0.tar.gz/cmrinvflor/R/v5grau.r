# Criado em:     2008-11-13                                                             
# Modificado em: 2010-03-24                                                          


#' @title Estimativa do volume a qualquer altura utilizando o polinomio de quinto grau
#' 
#' @description  Estimativa do volume a qualquer altura utilizando o polinomio de quinto grau
#' 
#' @details Todos os vetores das variáveis de entrada devem ter o mesmo tamanho
#' inclusive os vetores de coeficientes
#' 
#' @param hi Iésima altura do fuste
#' @param dap Diâmetro à 1,3 metros de altura do solo
#' @param C0 Coeficiente C0
#' @param C1 Coeficiente C1
#' @param C2 Coeficiente C2
#' @param C3 Coeficiente C3
#' @param C4 Coeficiente C4
#' @param C5 Coeficiente C5
#' @return São retornados os volumes para as iésimas alturas dos fustes
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.br},\cr 
#' Monica F. B. M. Thiersch \email{engagri@@yahoo.com.br}.
#' @keywords Afilamento Taper
#' @rdname v5grau
#' @export
v5grau<-function (hi,dap,c0,c1,c2,c3,c4,c5){
  v = (((c0 ^ 2) * hi) + ((c1 ^ 2) * ((hi ^ 3) / 3))
  + ((c2 ^ 2) * ((hi ^ 5) / 5)) + ((c3 ^ 2) * ((hi ^ 7) / 7))
  + ((c4 ^ 2) * ((hi ^ 9) / 9)) + ((c5 ^ 2) * ((hi ^ 11) / 11))
  + (2 * c0 * c1 * ((hi ^ 2) / 2)) + (2 * c0 * c2 * ((hi ^ 3) / 3))
  + (2 * c0 * c3 * ((hi ^ 4) / 4)) + (2 * c0 * c4 * ((hi ^ 5) / 5))
  + (2 * c0 * c5 * ((hi ^ 6) / 6)) + (2 * c1 * c2 * ((hi ^ 4) / 4))
  + (2 * c1 * c3 * ((hi ^ 5) / 5)) + (2 * c1 * c4 * ((hi ^ 6) / 6))
  + (2 * c1 * c5 * ((hi ^ 7) / 7)) + (2 * c2 * c3 * ((hi ^ 6) / 6))
  + (2 * c2 * c4 * ((hi ^ 7) / 7)) + (2 * c2 * c5 * ((hi ^ 8) / 8))
  + (2 * c3 * c4 * ((hi ^ 8) / 8)) + (2 * c3 * c5 * ((hi ^ 9) / 9))
  + (2 * c4 * c5 * ((hi ^ 10) / 10))) * ((pi * (dap ^ 2)) / 40000);
  return(v);
}
