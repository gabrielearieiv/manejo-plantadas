# Criado em:     2011-06-17                                                          
# Modificado em: 2011-06-17                                                         


#' @title Calculo do valor presente
#' 
#' @description  Analises economicas - Calculo do valor presente
#' 
#' @param rc 'data frame'\cr
#'  ..$ [[1]]:    Período de ocorrência da receita ou custo. Ex: ano, mês, etc.\cr
#'  ..$ [[2]]:    Valor da receita ou custo
#' @param x Taxa de juros (anual, mensal, etc.)
#' @return Valor presente liquido
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.br},\cr 
#' Monica F. B. M. Thiersch \email{engagri@@yahoo.com.br}.
#' @keywords vp
#' @rdname vp
#' @export
vp<-function(rc, x){
  rcp <- rc[, 2] / ((1 + x) ^ rc[, 1]);
  return(sum(rcp));
}
