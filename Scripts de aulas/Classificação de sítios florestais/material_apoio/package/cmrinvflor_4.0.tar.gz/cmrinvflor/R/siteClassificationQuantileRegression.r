# Criado em:     2012-09-22
# Modificado em: 2024-06-25

#' @title Site classification by quantile regression
#' @description  Site classification by quantile regression
#' @param equation 'list'\cr
#'  ..$ required_variables Variáveis obrigatórias\cr
#'  ..$ fpred Função para predição da variável de interesse\cr
#'  ..$ parms 'data.frame' Parâmetros estimados para diferentes percentis
#' @param continuous_sample_plots: 'data frame'\cr
#'  ..$ id: chave primária de identificação da amostra\cr
#'  ..$ Variáveis definidas em equation$required_variables exceto equation$interest_variable
#' @param reference_age: Idade de referência (default: 72 meses)
#' @param n_class: Número de classes desejadas.
#' @param way_counting_migrations: forma de contagem das migrações\cr
#'  ..$ 1: Migrações independentes da idade de medição\cr
#'  ..$ 2: Migrações em cada idade de medição 
#' @param plot_curves: Plotar um gráfico com as curvas estimadas e as alturas dominantes observadas (default: TRUE).
#' @return $ 'list'\cr 
#' ....$ continuous_sample_plots: 'data frame'\cr 
#' ....$ id: chave primária de identificação da amostra\cr
#' ....$ Variáveis definidas em equation$required_variables exceto equation$interest_variable
#' ....$ Alturas dominantes estimadas por todas as curvas em todas as idades de medição \cr 
#' ....$ is: Índice de sítio de cada amostra/medição \cr 
#' ....$ nmudou: Número de vezes que cada amostra mudou de classe de sítio \cr 
#' ....$ nis: Idêntico ao vetor 'is' para posterior reclassificação manual. \cr
#' ..$ classes: 'data frame' contendo as alturas dominantes estimadas por todas as curvas na idade de referência.\cr 
#' ..$ is_s: 'data frame'
#' ....$is: Índice de sítio\cr 
#' ....$s: Valor médio da classe de sítio\cr 
#' ..$ estabilidade: 'data frame'
#' ....$migracao: Número de mudanças de classes de sítio \cr 
#' ....$n_ocorrencia: Número de ocorrências de cada migração \cr 
#' ....$percmudanca: Percentual de ocorrências de cada migração
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.br},\cr 
#' Monica Fabiana Bento Moreira \email{engagri@@yahoo.com.br}.
#' @rdname siteClassificationAlgebraicDifference
#' @export

siteClassificationQuantileRegression<-function(
    equation, 
    continuous_sample_plots, 
    reference_age=72, 
    n_class=NA, 
    way_counting_migrations=1, 
    plot_curves=T
){
  rv<-c("id",equation$required_variables)
  jj<-rv %in% c(names(continuous_sample_plots), equation$future_age_variable, equation$future_dominant_height_variable)
  if(sum(jj)<length(rv)){
    stop(
      script('Não foram localizadas as variáveis obrigatórias:', rv[!jj], collapse=' '), 
      call. = F
    )
  }
  hd_id_ref<-data.frame(eqs=1:nrow(equation$parms))
  hd_id_ref[[equation$present_age_variable]]<-reference_age
  hd_id_ref$sitio<-NA
  for(i in 1:nrow(hd_id_ref)) hd_id_ref$sitio[i]<-equation$fpred(hd_id_ref[i,],equation$parms[i,])
  
  if (length(n_class)==1){
    site_class_limits<-round(seq(min(hd_id_ref$sitio), max(hd_id_ref$sitio), len=n_class+1), 2);
    site_class_limits<-sort(site_class_limits[c(-1,-(n_class+1))],decreasing = T);
  }else{
    site_class_limits<-sort(n_class, decreasing = T);
  } 
  ncurvas<-length(site_class_limits);
  classes<-data.frame(nomcol=paste('lscl',2:(ncurvas+1),sep=''),s=site_class_limits,stringsAsFactors =F);
  
  f<-function(cls, hd_id_ref, parms){
    res<-abs(cls$s-hd_id_ref$sitio)
    ii<-match(min(res),res)
    return(cbind(cls,parms[ii,]))
  }
  classes<-Reduce('rbind', lapply(split(classes,1:ncurvas), f, hd_id_ref, equation$parms))
  
  for(i in ncurvas:1){
    continuous_sample_plots[[classes[i,1]]]<-equation$fpred(continuous_sample_plots, classes[i,])
  }
  
  hd_id_ref$cls<-cut(hd_id_ref$sitio,breaks=c(-Inf,sort(classes$s),Inf))
  is_s<-aggregate(list(s=hd_id_ref$sitio),list(cls=hd_id_ref$cls), mean, na.rm=T)
  is_s$s<-round(is_s$s,2)
  is_s<-is_s[order(is_s$s,decreasing = T),]
  is_s$is<-1:nrow(is_s)
  is_s$cls<-NULL
  is_s<-is_s[,c('is','s')]
  
  if(plot_curves==T){
    dados_graf<-continuous_sample_plots[order(continuous_sample_plots[[equation$present_age_variable]]),];
    with(dados_graf, plot(
      x=dados_graf[[equation$present_age_variable]], 
      y=dados_graf[[equation$interest_variable]], 
      ylim=c(0,40), 
      pch='*', 
      col='green', 
      xlab=equation$present_age_variable, 
      ylab=equation$interest_variable
    ));
    for(i in ncurvas:1){
      lines(dados_graf[[equation$present_age_variable]], dados_graf[,classes[i,1]], col=i);
    }
    legend(
      "bottomright",
      legend=round(classes[,2],2),
      col=1:ncurvas,
      lty=rep(1,ncurvas), 
      lwd=rep(2.5,ncurvas), 
      cex=0.8, 
      box.col="white", 
      bty="n"
    );
    legend(
      "topleft",
      legend=paste0("s",is_s$is,":",is_s$s), 
      col=1:nrow(is_s), 
      cex=0.8, 
      box.col="white", 
      bty="n"
    )
  }
  continuous_sample_plots$is<-NA;
  for(i in ncurvas:1){
    continuous_sample_plots$is[
      continuous_sample_plots[[equation$interest_variable]]<continuous_sample_plots[,classes[i,1]] & 
      is.na(continuous_sample_plots$is)
    ]<-i+1;
  }
  continuous_sample_plots$is[is.na(continuous_sample_plots$is)]<-1

  #forma de contagem das migrações
  #1: Migrações independente da idade de medição
  #2: Migrações em cada idade de medição
  if(is.na(way_counting_migrations)|way_counting_migrations!=2) way_counting_migrations<-1
  if(way_counting_migrations==1){
    f<-function(x){
      if(nrow(x)>1){
        x<-x[order(x$is),]
        resp<-data.frame(id=x$id[1], nmudou=sum(diff(x$is)))
      } else{
        resp<-data.frame(id=x$id[1], nmudou=0)
      }
      return(resp)
    }
    calc<-Reduce('rbind', lapply(split(continuous_sample_plots,continuous_sample_plots$id),f))
  }else{
    f<-function(x){
      if(nrow(x)>1){
        x<-x[order(x$idade1),]
        resp<-data.frame(id=x$id[1], nmudou=sum(abs(diff(x$is))))
      } else{
        resp<-data.frame(id=x$id[1], nmudou=0)
      }
      return(resp)
    }
    calc<-Reduce('rbind', lapply(split(continuous_sample_plots,continuous_sample_plots$id),f))
  }
  
  continuous_sample_plots<-merge(x = continuous_sample_plots, y = calc, by = "id",  all.x=T,sort=F);
  continuous_sample_plots$nis<-continuous_sample_plots$is;

  estabilidade<-aggregate(list(n_ocorrencia=calc$id),list(migracao=calc$nmudou),length);
  estabilidade$percmudanca<-with(estabilidade,round(n_ocorrencia/sum(n_ocorrencia)*100,2));
  
  names(classes)[1:2]<-c('limite',paste('hdiref_',reference_age,sep=''));
  
  continuous_sample_plots<-continuous_sample_plots[
    order(
      continuous_sample_plots$id, 
      continuous_sample_plots[[equation$present_age_variable]]
    ),
  ];
  return(list(
    continuous_sample_plots=continuous_sample_plots,
    classes=classes,
    is_s=is_s,
    estabilidade=estabilidade
  ))
}
