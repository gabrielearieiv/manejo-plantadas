# Criado em:     2010-05-19                                                          
# Modificado em: 2021-11-19                                                          

#' @title Funcao para pareamento de medicoes sucessivas
#' 
#' @description  Função para pareamento de medições sucessivas
#' 
#' @param  dfdados 'data frame'\cr
#'  ..$ [[1]]:    Variável que define a unidade amostral\cr
#'  ..$ [[2]]:    Variável que identifica a sequência das medições\cr
#'  ..$ [[1:n]]:  1 a n variáveis a serem pareadas
#' @return dfdados: 'data frame'\cr 
#' ..$ [[1]]: Variável que define a unidade amostral\cr 
#' ..$ [[1:n]]: 1 a n variáveis pareadas utilizando os índices 1 e 2
#' @author Cláudio Roberto Thiersch \email{crthiersch@@ufscar.br},\cr 
#' Monica F. B. M. Thiersch \email{engagri@@yahoo.com.br}.
#' @keywords parear_seqmed
#' @rdname parear_seqmed
#' @export
parear_seqmed<-function (dfdados){
  dfdados<-dfdados[order(dfdados[[1]], dfdados[[2]]),];
  nv<-names(dfdados);
  nc<-length(nv);
  
  nv1<-c(nv[1],paste(nv[2:nc],1,sep=''));
  nv2<-c(nv[1],paste(nv[2:nc],2,sep=''));

  nv<-nv1[1];
  for (i in 2:nc){
    nv<-c(nv,nv1[i],nv2[i]);  
  }

  dfdados1<-dfdados[-nrow(dfdados),];
  dfdados2<-dfdados[-1,];
  
  names(dfdados1)<-nv1;
  names(dfdados2)<-nv2;
  
  dfdados<-cbind(dfdados1,dfdados2[,-1]);
  dfdados<-dfdados[dfdados1[[1]]==dfdados2[[1]], nv];
  return(dfdados);
}
